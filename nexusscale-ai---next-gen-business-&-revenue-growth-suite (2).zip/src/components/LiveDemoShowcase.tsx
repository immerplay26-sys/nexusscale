import React from 'react';
import { useApp } from '../context/AppContext';
import { 
  Flame, 
  Send, 
  Search, 
  Rocket, 
  FileText, 
  ArrowRight, 
  Sparkles, 
  CheckCircle2, 
  TrendingUp,
  Cpu
} from 'lucide-react';
import { ActiveTab } from '../types';

export const LiveDemoShowcase: React.FC = () => {
  const { setActiveTab } = useApp();

  const tools = [
    {
      id: 'viral-tool' as ActiveTab,
      badge: 'High Engagement',
      title: 'AI Viral Hook & Social Video Studio',
      subtitle: 'Trained on 10,000+ videos with 1M+ views across TikTok, Reels, YouTube Shorts, and X.',
      benefits: [
        '3 Psychological Hooks (Curiosity gap, Contrarian, Story loop)',
        'Full 60-Second Timed Script with B-roll audio/visual cues',
        'High-CTR thumbnail concept & targeted hashtag matrix',
      ],
      icon: Flame,
      color: 'from-amber-500 to-orange-600',
      textColor: 'text-amber-400',
      borderGlow: 'hover:border-amber-500/40',
      actionLabel: 'Launch Viral Script Studio',
    },
    {
      id: 'outreach-tool' as ActiveTab,
      badge: 'High Ticket Closer',
      title: 'B2B Cold Outreach & Pitch Closer',
      subtitle: 'Write non-spammy, high-converting cold email sequences that book $3,000 to $15,000 agency retainers.',
      benefits: [
        '3-Part Follow-up sequence with 68%+ average open rates',
        'LinkedIn 300-character high-acceptance connection pitch',
        'Objection handling scripts for "No budget" and "Have an agency"',
      ],
      icon: Send,
      color: 'from-emerald-500 to-teal-600',
      textColor: 'text-emerald-400',
      borderGlow: 'hover:border-emerald-500/40',
      actionLabel: 'Open B2B Outreach Closer',
    },
    {
      id: 'seo-tool' as ActiveTab,
      badge: 'Organic Search Traffic',
      title: 'Programmatic SEO & Keyword Intel',
      subtitle: 'Identify high-intent, low-competition keywords that bring free targeted buyers straight from Google.',
      benefits: [
        'Keyword volume, difficulty index, and estimated CPC valuation',
        'Click-winning Title Tags & 155-char Meta Descriptions',
        'Ready-to-deploy JSON-LD FAQ Schema markup for Rich Snippets',
      ],
      icon: Search,
      color: 'from-cyan-500 to-blue-600',
      textColor: 'text-cyan-400',
      borderGlow: 'hover:border-cyan-500/40',
      actionLabel: 'Run SEO Intelligence Tool',
    },
    {
      id: 'validator-tool' as ActiveTab,
      badge: 'Venture Scaling',
      title: 'Micro-SaaS & Idea Validator',
      subtitle: 'Validate digital product concepts, calculate Total Addressable Market (TAM), and build 30-day GTM roadmaps.',
      benefits: [
        'Viability Scorecard (0–100) & Problem Urgency evaluation',
        'Optimal Tiered Monetization pricing breakdown',
        '30-Day Step-by-step Go-to-Market launch blueprint',
      ],
      icon: Rocket,
      color: 'from-purple-500 to-indigo-600',
      textColor: 'text-purple-400',
      borderGlow: 'hover:border-purple-500/40',
      actionLabel: 'Validate Your SaaS Idea',
    },
    {
      id: 'proposal-tool' as ActiveTab,
      badge: 'Instant Deal Maker',
      title: 'Client Proposal & Deal Closer',
      subtitle: 'Generate professional, binding Statements of Work (SOW) and invoices ready for client e-signatures.',
      benefits: [
        'Structured Milestones, Deliverables, and Payment terms',
        'Clean printable design for instant PDF export',
        'Protects intellectual property & guarantees payment schedules',
      ],
      icon: FileText,
      color: 'from-rose-500 to-pink-600',
      textColor: 'text-rose-400',
      borderGlow: 'hover:border-rose-500/40',
      actionLabel: 'Draft Instant Client Agreement',
    },
  ];

  return (
    <section className="py-16 md:py-24 bg-[#090d15] border-y border-white/5 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14 space-y-3">
          <div className="inline-flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-emerald-400 bg-emerald-500/10 px-3 py-1 rounded-full border border-emerald-500/20">
            <Cpu className="w-3.5 h-3.5" />
            <span>5 Specialized Revenue Super-Tools</span>
          </div>
          <h2 className="text-2xl sm:text-4xl font-extrabold text-white tracking-tight">
            Everything You Need to Scale to Thousands of Dollars Monthly
          </h2>
          <p className="text-sm sm:text-base text-slate-400">
            Click into any tool below to test live generation immediately. Designed to automate 90% of your business work.
          </p>
        </div>

        {/* Tools Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {tools.map((tool) => {
            const Icon = tool.icon;
            return (
              <div
                key={tool.id}
                className={`p-6 rounded-2xl bg-[#0d1320] border border-white/5 transition-all duration-300 flex flex-col justify-between group ${tool.borderGlow} hover:shadow-xl hover:shadow-emerald-500/5`}
              >
                <div>
                  {/* Top Bar */}
                  <div className="flex items-center justify-between mb-4">
                    <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${tool.color} p-0.5 shadow-md flex items-center justify-center`}>
                      <div className="w-full h-full bg-[#0a0f19] rounded-[10px] flex items-center justify-center">
                        <Icon className={`w-6 h-6 ${tool.textColor}`} />
                      </div>
                    </div>
                    <span className="text-[11px] font-semibold tracking-wide text-slate-400 bg-white/5 px-2.5 py-1 rounded-md border border-white/5">
                      {tool.badge}
                    </span>
                  </div>

                  {/* Title & Desc */}
                  <h3 className="text-lg font-bold text-white mb-2 group-hover:text-emerald-300 transition-colors">
                    {tool.title}
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-400 leading-relaxed mb-5">
                    {tool.subtitle}
                  </p>

                  {/* Features List */}
                  <ul className="space-y-2 mb-6">
                    {tool.benefits.map((benefit, i) => (
                      <li key={i} className="flex items-start gap-2 text-xs text-slate-300">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                        <span>{benefit}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Launch Button */}
                <button
                  onClick={() => setActiveTab(tool.id)}
                  className="w-full py-2.5 px-4 rounded-xl bg-white/5 hover:bg-emerald-500 hover:text-slate-950 text-slate-200 font-bold text-xs sm:text-sm transition-all flex items-center justify-center gap-2 group/btn"
                >
                  <span>{tool.actionLabel}</span>
                  <ArrowRight className="w-4 h-4 group-hover/btn:translate-x-1 transition-transform" />
                </button>
              </div>
            );
          })}

          {/* 6th Card: All-In-One Revenue Engine Hub */}
          <div className="p-6 rounded-2xl bg-gradient-to-br from-[#0c1626] to-[#0d222e] border border-emerald-500/20 flex flex-col justify-between">
            <div>
              <div className="w-12 h-12 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center mb-4">
                <TrendingUp className="w-6 h-6" />
              </div>
              <span className="text-[11px] font-semibold tracking-wide text-emerald-400 bg-emerald-500/10 px-2.5 py-1 rounded-md border border-emerald-500/20">
                Turnkey Monetization
              </span>
              <h3 className="text-lg font-bold text-white mt-3 mb-2">
                Need Custom White-Label or Complete Agency Setup?
              </h3>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed mb-4">
                We help you clone, deploy, and customize this exact software ecosystem under your own custom domain with custom payment gateways.
              </p>
              <div className="p-3 rounded-xl bg-black/30 border border-white/5 text-xs text-slate-300 space-y-1">
                <p>⚡ <strong>Founder Hotline:</strong> +923199389323</p>
                <p>✉️ <strong>Direct Email:</strong> muhammadofficial356@gmail.com</p>
              </div>
            </div>

            <button
              onClick={() => setActiveTab('contact')}
              className="w-full mt-6 py-2.5 px-4 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-extrabold text-xs sm:text-sm transition-all flex items-center justify-center gap-2"
            >
              <span>Contact Muhammad Directly</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>

      </div>
    </section>
  );
};
