import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  Check, 
  Sparkles, 
  Zap, 
  ShieldCheck, 
  ArrowRight, 
  Crown,
  MessageCircle
} from 'lucide-react';

export const PricingSection: React.FC = () => {
  const { 
    settings, 
    setCheckoutModalOpen, 
    setSelectedPlan 
  } = useApp();

  const [billingCycle, setBillingCycle] = useState<'monthly' | 'annual'>('monthly');

  // Annual discount calculation (20% off)
  const discountMultiplier = billingCycle === 'annual' ? 0.8 : 1.0;

  const starterPrice = Math.round(settings.starterPrice * discountMultiplier);
  const proPrice = Math.round(settings.proPrice * discountMultiplier);
  const agencyPrice = Math.round(settings.agencyPrice * discountMultiplier);

  const plans = [
    {
      id: 'Starter' as const,
      name: 'Starter Solo',
      price: starterPrice,
      desc: 'Ideal for independent content creators, solo freelancers, and beginner entrepreneurs.',
      popular: false,
      features: [
        '50 AI Viral Video Hooks & Scripts/mo',
        '25 High-Ticket B2B Cold Outreach Pitches',
        'Programmatic SEO Outline Generator',
        'Single User Access',
        'Standard Export (Text, Markdown)',
        'Community & Email Support',
      ],
      cta: 'Start with Starter',
      highlightColor: 'border-white/10',
    },
    {
      id: 'Pro' as const,
      name: 'Growth Pro',
      price: proPrice,
      desc: 'The complete revenue engine for ambitious agencies, consultants, and growth hackers.',
      popular: true,
      features: [
        'Unlimited AI Viral Hook & 60s Script Generations',
        'Unlimited B2B High-Ticket Outreach Sequences',
        'Programmatic SEO & Rich FAQ Schema Maker',
        'Micro-SaaS & Venture TAM Validator',
        'Client Statement of Work & Proposal Builder',
        'Priority Ultra-Fast AI Execution Speed',
        'Full Commercial Resale Rights',
        'Direct WhatsApp Strategy Support',
      ],
      cta: 'Get Growth Pro Access',
      highlightColor: 'border-emerald-500/50 shadow-2xl shadow-emerald-500/10 ring-1 ring-emerald-500/30',
    },
    {
      id: 'Agency' as const,
      name: 'Agency Enterprise',
      price: agencyPrice,
      desc: 'For top marketing agencies, scaling startups, and multi-team operations needing custom setups.',
      popular: false,
      features: [
        'Everything in Growth Pro Included',
        'Up to 10 Team Seats & Shared Workspaces',
        'Custom Brand / White-Label Client Exports',
        'VIP Direct 1-on-1 Onboarding with Muhammad',
        'Dedicated WhatsApp VIP Hotline (+923199389323)',
        'Custom Integrations & Dedicated Server Priority',
        'Early Access to All Future Super-Tools',
      ],
      cta: 'Deploy Agency Enterprise',
      highlightColor: 'border-cyan-500/30',
    },
  ];

  const handleSelectPlan = (planId: 'Starter' | 'Pro' | 'Agency') => {
    setSelectedPlan(planId);
    setCheckoutModalOpen(true);
  };

  return (
    <section className="py-16 md:py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
      {/* Title */}
      <div className="text-center max-w-3xl mx-auto mb-10 space-y-3">
        <div className="inline-flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-emerald-400 bg-emerald-500/10 px-3 py-1 rounded-full border border-emerald-500/20">
          <Zap className="w-3.5 h-3.5" />
          <span>Transparent, Value-Packed Pricing</span>
        </div>
        <h2 className="text-2xl sm:text-4xl font-extrabold text-white tracking-tight">
          Invest in High-Leverage Tools that Pay for Themselves
        </h2>
        <p className="text-sm sm:text-base text-slate-400">
          No hidden fees, no restrictive contracts. Cancel or upgrade anytime with a 30-day money-back guarantee.
        </p>

        {/* Billing Toggle */}
        <div className="pt-4 flex items-center justify-center gap-3">
          <span className={`text-xs font-semibold ${billingCycle === 'monthly' ? 'text-white' : 'text-slate-400'}`}>
            Monthly Billing
          </span>
          <button
            onClick={() => setBillingCycle(billingCycle === 'monthly' ? 'annual' : 'monthly')}
            className="w-12 h-6 rounded-full bg-slate-800 p-1 flex items-center transition border border-white/10"
            aria-label="Toggle Billing Cycle"
          >
            <div
              className={`w-4 h-4 rounded-full bg-emerald-400 transition-transform ${
                billingCycle === 'annual' ? 'translate-x-6' : 'translate-x-0'
              }`}
            />
          </button>
          <div className="flex items-center gap-1.5">
            <span className={`text-xs font-semibold ${billingCycle === 'annual' ? 'text-white' : 'text-slate-400'}`}>
              Annual Billing
            </span>
            <span className="text-[10px] font-bold text-emerald-400 bg-emerald-500/15 border border-emerald-500/30 px-2 py-0.5 rounded-full">
              Save 20%
            </span>
          </div>
        </div>
      </div>

      {/* Pricing Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-stretch">
        {plans.map((plan) => (
          <div
            key={plan.id}
            className={`p-6 sm:p-8 rounded-2xl bg-[#0c121e] border ${plan.highlightColor} relative flex flex-col justify-between transition-all hover:scale-[1.01]`}
          >
            {plan.popular && (
              <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 font-extrabold text-[11px] uppercase tracking-wider shadow-md flex items-center gap-1">
                <Crown className="w-3.5 h-3.5" />
                <span>Most Popular Choice</span>
              </div>
            )}

            <div>
              <div className="flex justify-between items-baseline mb-2">
                <h3 className="text-xl font-bold text-white">{plan.name}</h3>
              </div>
              <p className="text-xs text-slate-400 min-h-[36px] mb-5">{plan.desc}</p>

              {/* Price Display */}
              <div className="mb-6 pb-6 border-b border-white/5">
                <div className="flex items-baseline gap-1">
                  <span className="text-4xl font-extrabold text-white">${plan.price}</span>
                  <span className="text-xs text-slate-400 font-medium">
                    / {billingCycle === 'annual' ? 'mo (billed annually)' : 'month'}
                  </span>
                </div>
                <p className="text-[11px] text-emerald-400 font-medium mt-1">
                  ≈ Rs. {(plan.price * 278).toLocaleString()} PKR / month
                </p>
              </div>

              {/* Feature Items */}
              <div className="space-y-3 mb-8">
                <p className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
                  Included Super-Features:
                </p>
                {plan.features.map((feature, i) => (
                  <div key={i} className="flex items-start gap-2.5 text-xs text-slate-300">
                    <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <span>{feature}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Action CTA */}
            <div>
              <button
                onClick={() => handleSelectPlan(plan.id)}
                className={`w-full py-3 px-4 rounded-xl font-bold text-sm transition-all flex items-center justify-center gap-2 ${
                  plan.popular
                    ? 'bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 shadow-lg shadow-emerald-500/25'
                    : 'bg-white/5 hover:bg-white/10 text-white border border-white/10'
                }`}
              >
                <span>{plan.cta}</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <p className="text-[11px] text-center text-slate-400 mt-2.5">
                Instant activation · Cancel anytime
              </p>
            </div>
          </div>
        ))}
      </div>

      {/* Enterprise Custom Note with Muhammad's Contact */}
      <div className="mt-12 p-6 rounded-2xl bg-gradient-to-r from-[#0c1828] to-[#0d222e] border border-white/10 flex flex-col sm:flex-row items-center justify-between gap-6">
        <div className="space-y-1 text-center sm:text-left">
          <h4 className="text-base font-bold text-white">Need a Custom Enterprise or White-Label License?</h4>
          <p className="text-xs sm:text-sm text-slate-300">
            Speak directly with Founder Muhammad via WhatsApp or Email for custom payment methods (JazzCash, EasyPaisa, Direct Bank Transfer, Crypto, or Wire).
          </p>
        </div>
        <a
          href={`https://wa.me/${settings.whatsappNumber.replace(/[^0-9]/g, '')}?text=Hello%20Muhammad,%20I%20want%20to%20inquire%20about%20Custom%20Agency%20Plan`}
          target="_blank"
          rel="noopener noreferrer"
          className="shrink-0 px-5 py-2.5 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 hover:bg-emerald-500/30 font-bold text-xs sm:text-sm transition flex items-center gap-2"
        >
          <MessageCircle className="w-4 h-4 text-emerald-400" />
          <span>Chat on WhatsApp (+923199389323)</span>
        </a>
      </div>
    </section>
  );
};
