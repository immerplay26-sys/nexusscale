import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  Calculator, 
  TrendingUp, 
  DollarSign, 
  Clock, 
  Sparkles, 
  ArrowRight,
  ShieldCheck
} from 'lucide-react';

export const ROICalculator: React.FC = () => {
  const { setCheckoutModalOpen, setSelectedPlan } = useApp();

  const [pitchesPerMonth, setPitchesPerMonth] = useState<number>(150);
  const [dealValue, setDealValue] = useState<number>(1500); // $1500 average retainer/sale
  const [closeRate, setCloseRate] = useState<number>(4); // 4% conversion
  const [contentPosts, setContentPosts] = useState<number>(25);

  // Math
  const estimatedDealsClosed = Math.max(1, Math.round((pitchesPerMonth * closeRate) / 100));
  const estimatedMonthlyGross = estimatedDealsClosed * dealValue;
  const hoursSaved = Math.round((pitchesPerMonth * 0.4) + (contentPosts * 3));
  const softwareCost = 79; // Pro plan
  const netProfitUSD = estimatedMonthlyGross - softwareCost;
  const netProfitPKR = Math.round(netProfitUSD * 278); // Approx 1 USD = 278 PKR
  const lakhsPKR = (netProfitPKR / 100000).toFixed(1);

  return (
    <section className="py-16 md:py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      {/* Title */}
      <div className="text-center max-w-3xl mx-auto mb-12 space-y-3">
        <div className="inline-flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-emerald-400 bg-emerald-500/10 px-3 py-1 rounded-full border border-emerald-500/20">
          <Calculator className="w-3.5 h-3.5" />
          <span>Interactive Profit & Earnings Predictor</span>
        </div>
        <h2 className="text-2xl sm:text-4xl font-extrabold text-white tracking-tight">
          Calculate Your Projected Monthly Earnings
        </h2>
        <p className="text-sm sm:text-base text-slate-400">
          Adjust the sliders below to see realistic monthly revenue potential by automating high-ticket client closing & viral distribution.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Controls Column (7 Cols) */}
        <div className="lg:col-span-7 p-6 sm:p-8 rounded-2xl bg-[#0d1320] border border-white/5 shadow-xl space-y-6">
          <h3 className="text-base font-bold text-white flex items-center gap-2 border-b border-white/5 pb-3">
            <Sparkles className="w-4 h-4 text-emerald-400" />
            <span>Operational Activity Parameters</span>
          </h3>

          {/* Slider 1: Monthly Outreaches */}
          <div className="space-y-2">
            <div className="flex justify-between items-center text-xs sm:text-sm">
              <label className="font-semibold text-slate-300">
                Monthly High-Ticket Outreaches / Pitches:
              </label>
              <span className="font-mono font-bold text-emerald-400 text-base">
                {pitchesPerMonth} pitches
              </span>
            </div>
            <input
              type="range"
              min="20"
              max="600"
              step="10"
              value={pitchesPerMonth}
              onChange={(e) => setPitchesPerMonth(Number(e.target.value))}
              className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-emerald-500"
            />
            <div className="flex justify-between text-[11px] text-slate-400">
              <span>20 (Casual)</span>
              <span>300 (Active Agency)</span>
              <span>600 (Growth Engine)</span>
            </div>
          </div>

          {/* Slider 2: Average Deal Value */}
          <div className="space-y-2">
            <div className="flex justify-between items-center text-xs sm:text-sm">
              <label className="font-semibold text-slate-300">
                Average Client Retainer or Product Price ($):
              </label>
              <span className="font-mono font-bold text-emerald-400 text-base">
                ${dealValue.toLocaleString()} USD
              </span>
            </div>
            <input
              type="range"
              min="300"
              max="5000"
              step="100"
              value={dealValue}
              onChange={(e) => setDealValue(Number(e.target.value))}
              className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-emerald-500"
            />
            <div className="flex justify-between text-[11px] text-slate-400">
              <span>$300 (Micro product)</span>
              <span>$2,500 (Agency Retainer)</span>
              <span>$5,000+ (High-Ticket)</span>
            </div>
          </div>

          {/* Slider 3: Close Rate */}
          <div className="space-y-2">
            <div className="flex justify-between items-center text-xs sm:text-sm">
              <label className="font-semibold text-slate-300">
                Expected Reply-to-Close Rate (%):
              </label>
              <span className="font-mono font-bold text-cyan-400 text-base">
                {closeRate}% Conversion
              </span>
            </div>
            <input
              type="range"
              min="1"
              max="15"
              step="1"
              value={closeRate}
              onChange={(e) => setCloseRate(Number(e.target.value))}
              className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-500"
            />
            <div className="flex justify-between text-[11px] text-slate-400">
              <span>1% (Conservative)</span>
              <span>5% (Industry Standard)</span>
              <span>15% (Hyper-Targeted)</span>
            </div>
          </div>

          {/* Slider 4: Monthly Content Posts */}
          <div className="space-y-2">
            <div className="flex justify-between items-center text-xs sm:text-sm">
              <label className="font-semibold text-slate-300">
                Monthly Viral Videos & SEO Posts Produced:
              </label>
              <span className="font-mono font-bold text-purple-400 text-base">
                {contentPosts} assets
              </span>
            </div>
            <input
              type="range"
              min="5"
              max="90"
              step="5"
              value={contentPosts}
              onChange={(e) => setContentPosts(Number(e.target.value))}
              className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-purple-500"
            />
            <div className="flex justify-between text-[11px] text-slate-400">
              <span>5 / mo</span>
              <span>30 / mo (1 per day)</span>
              <span>90 / mo (Multi-channel)</span>
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-900/60 border border-white/5 text-xs text-slate-400 flex items-center gap-2">
            <Clock className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>Estimated time saved by automating with NexusScale AI: <strong>~{hoursSaved} hours/month</strong> (worth over $3,500 in freelance labor).</span>
          </div>

        </div>

        {/* Results Card (5 Cols) */}
        <div className="lg:col-span-5 p-6 sm:p-8 rounded-2xl bg-gradient-to-b from-[#0c1828] to-[#09111c] border border-emerald-500/30 shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 right-0 w-48 h-48 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none" />

          <p className="text-xs font-bold uppercase tracking-wider text-emerald-400 mb-1">
            Projected Monthly Output
          </p>
          <h3 className="text-lg font-extrabold text-white mb-6">
            Your Monthly Scaled Profit Potential
          </h3>

          {/* Primary Metric: USD */}
          <div className="p-5 rounded-2xl bg-black/40 border border-emerald-500/20 mb-4">
            <p className="text-xs text-slate-400 mb-1">Estimated Net Revenue (USD):</p>
            <div className="flex items-baseline gap-2">
              <span className="text-3xl sm:text-4xl font-black text-emerald-400">
                ${netProfitUSD.toLocaleString()}
              </span>
              <span className="text-xs font-semibold text-slate-400">/ month</span>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              Based on closing ~{estimatedDealsClosed} new deal{estimatedDealsClosed > 1 ? 's' : ''} at ${dealValue}
            </p>
          </div>

          {/* Secondary Metric: PKR / Lakhs */}
          <div className="p-4 rounded-xl bg-white/[0.03] border border-white/5 mb-6">
            <div className="flex items-center justify-between text-xs text-slate-300">
              <span>Pakistani Rupee Conversion:</span>
              <span className="font-bold text-cyan-300 text-sm font-mono">
                Rs. {netProfitPKR.toLocaleString()}
              </span>
            </div>
            <div className="mt-1 flex items-center justify-between">
              <span className="text-xs text-slate-400">Equivalent in Lakhs:</span>
              <span className="font-extrabold text-emerald-400 text-base">
                ~ {lakhsPKR} Lakh Rupees / Month
              </span>
            </div>
          </div>

          {/* Summary Breakdown */}
          <div className="space-y-2 text-xs text-slate-300 mb-6">
            <div className="flex justify-between border-b border-white/5 pb-1">
              <span>Estimated Closed Clients:</span>
              <span className="font-semibold text-white">{estimatedDealsClosed} Clients</span>
            </div>
            <div className="flex justify-between border-b border-white/5 pb-1">
              <span>Software Investment:</span>
              <span className="font-semibold text-slate-400">$79/mo (Pro)</span>
            </div>
            <div className="flex justify-between border-b border-white/5 pb-1">
              <span>Projected ROI Multiplier:</span>
              <span className="font-bold text-emerald-400">
                {(netProfitUSD / softwareCost).toFixed(0)}x Return on Investment
              </span>
            </div>
          </div>

          {/* Action CTA */}
          <button
            onClick={() => {
              setSelectedPlan('Pro');
              setCheckoutModalOpen(true);
            }}
            className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-sm shadow-lg shadow-emerald-500/20 transition-all flex items-center justify-center gap-2"
          >
            <span>Activate Your Revenue Engine Now</span>
            <ArrowRight className="w-4 h-4" />
          </button>

          <p className="text-[11px] text-center text-slate-400 mt-3 flex items-center justify-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>Backed by 30-Day Money Back Guarantee</span>
          </p>
        </div>

      </div>
    </section>
  );
};
