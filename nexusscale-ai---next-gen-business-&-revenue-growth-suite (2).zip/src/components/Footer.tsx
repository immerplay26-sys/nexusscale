import React from 'react';
import { useApp } from '../context/AppContext';
import { 
  Sparkles, 
  Mail, 
  Phone, 
  MessageCircle, 
  Lock, 
  ShieldCheck, 
  ArrowUpRight, 
  Award,
  Globe,
  Heart
} from 'lucide-react';
import { ActiveTab } from '../types';

export const Footer: React.FC = () => {
  const { 
    settings, 
    setActiveTab, 
    isAdminLoggedIn, 
    setActiveLegalModal, 
    setAffiliateModalOpen,
    setCheckoutModalOpen 
  } = useApp();

  const handleNav = (tab: ActiveTab) => {
    setActiveTab(tab);
  };

  const currentYear = new Date().getFullYear();

  return (
    <footer className="w-full bg-[#06080d] border-t border-white/5 pt-16 pb-12 text-slate-400">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 pb-12 border-b border-white/5">
          
          {/* Brand Info */}
          <div className="lg:col-span-2 space-y-4">
            <div 
              onClick={() => handleNav('home')} 
              className="flex items-center gap-2.5 cursor-pointer inline-flex"
            >
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-emerald-500 to-cyan-600 p-0.5 shadow-md shadow-emerald-500/20">
                <div className="w-full h-full bg-[#090e17] rounded-[10px] flex items-center justify-center">
                  <Sparkles className="w-4 h-4 text-emerald-400" />
                </div>
              </div>
              <span className="font-extrabold text-xl text-white tracking-tight">
                {settings.siteName}
              </span>
            </div>

            <p className="text-sm text-slate-400 leading-relaxed max-w-sm">
              {settings.tagline}. Designed to solve the biggest creator, agency, and business bottlenecks with cutting-edge automated revenue intelligence.
            </p>

            <div className="pt-2 space-y-2 text-xs">
              <a 
                href={`mailto:${settings.contactEmail}`}
                className="flex items-center gap-2 text-slate-300 hover:text-emerald-400 transition"
              >
                <Mail className="w-4 h-4 text-emerald-500" />
                <span>{settings.contactEmail}</span>
              </a>
              <a 
                href={`tel:${settings.contactPhone}`}
                className="flex items-center gap-2 text-slate-300 hover:text-emerald-400 transition"
              >
                <Phone className="w-4 h-4 text-emerald-500" />
                <span>{settings.contactPhone}</span>
              </a>
              <a 
                href={`https://wa.me/${settings.whatsappNumber.replace(/[^0-9]/g, '')}?text=Hello%20Muhammad,%20I%20am%20interested%20in%20NexusScale%20AI!`}
                target="_blank" 
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 hover:bg-emerald-500/20 transition font-medium"
              >
                <MessageCircle className="w-4 h-4" />
                <span>Chat on WhatsApp Directly</span>
              </a>
            </div>
          </div>

          {/* Quick Tools Navigation */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-200 mb-4">
              AI Super-Tools
            </h4>
            <ul className="space-y-2.5 text-sm">
              <li>
                <button onClick={() => handleNav('viral-tool')} className="hover:text-emerald-400 transition text-left">
                  Viral Hook & Script Studio
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('outreach-tool')} className="hover:text-emerald-400 transition text-left">
                  High-Ticket B2B Outreach Closer
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('seo-tool')} className="hover:text-emerald-400 transition text-left">
                  Programmatic SEO & Keywords
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('validator-tool')} className="hover:text-emerald-400 transition text-left">
                  Micro-SaaS & Idea Validator
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('proposal-tool')} className="hover:text-emerald-400 transition text-left">
                  Client Proposal & Invoice Maker
                </button>
              </li>
            </ul>
          </div>

          {/* Growth & Monetization */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-200 mb-4">
              Growth & Pricing
            </h4>
            <ul className="space-y-2.5 text-sm">
              <li>
                <button onClick={() => handleNav('pricing')} className="hover:text-emerald-400 transition text-left">
                  Subscription Plans
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('roi')} className="hover:text-emerald-400 transition text-left">
                  Monthly Revenue Calculator
                </button>
              </li>
              <li>
                <button onClick={() => setAffiliateModalOpen(true)} className="hover:text-emerald-400 transition text-left flex items-center gap-1 text-emerald-400">
                  <span>Affiliate Program (40%)</span>
                  <ArrowUpRight className="w-3.5 h-3.5" />
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('about')} className="hover:text-emerald-400 transition text-left">
                  Founder Story & Vision
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('contact')} className="hover:text-emerald-400 transition text-left">
                  Book a VIP Demo
                </button>
              </li>
            </ul>
          </div>

          {/* Legal & Administration */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-200 mb-4">
              Legal & Control
            </h4>
            <ul className="space-y-2.5 text-sm">
              <li>
                <button onClick={() => setActiveLegalModal('privacy')} className="hover:text-emerald-400 transition text-left">
                  Privacy Policy
                </button>
              </li>
              <li>
                <button onClick={() => setActiveLegalModal('terms')} className="hover:text-emerald-400 transition text-left">
                  Terms of Service
                </button>
              </li>
              <li>
                <button onClick={() => setActiveLegalModal('refund')} className="hover:text-emerald-400 transition text-left">
                  30-Day Money-Back Guarantee
                </button>
              </li>
              <li>
                <button 
                  onClick={() => handleNav(isAdminLoggedIn ? 'admin-dashboard' : 'admin-login')} 
                  className="hover:text-emerald-400 transition text-left flex items-center gap-1.5 text-slate-300 font-medium"
                >
                  <Lock className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Admin Gateway (/admin-login.html)</span>
                </button>
              </li>
            </ul>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <p>
            © {currentYear} {settings.siteName}. All rights reserved. Created & Engineered by Muhammad.
          </p>
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1 text-slate-400">
              <ShieldCheck className="w-4 h-4 text-emerald-500" />
              <span>256-Bit SSL Encrypted & GDPR Compliant</span>
            </span>
            <span className="hidden sm:inline">·</span>
            <span className="flex items-center gap-1 text-slate-400">
              <Globe className="w-3.5 h-3.5 text-cyan-400" />
              <span>Global Low-Latency Deployment Ready</span>
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
};
