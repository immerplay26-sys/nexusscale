import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  X, 
  Sparkles, 
  DollarSign, 
  CheckCircle2, 
  ArrowRight, 
  TrendingUp, 
  Copy, 
  Share2 
} from 'lucide-react';

export const AffiliateModal: React.FC = () => {
  const { affiliateModalOpen, setAffiliateModalOpen, addLead, settings } = useApp();
  const [partnerName, setPartnerName] = useState('');
  const [partnerEmail, setPartnerEmail] = useState('');
  const [partnerChannel, setPartnerChannel] = useState('');
  const [joined, setJoined] = useState(false);
  const [copied, setCopied] = useState(false);

  if (!affiliateModalOpen) return null;

  const sampleAffiliateLink = `https://${window.location.hostname || 'nexusscale.ai'}/?ref=${partnerName.toLowerCase().replace(/\s+/g, '') || 'partner'}`;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!partnerName.trim() || !partnerEmail.trim()) return;

    addLead({
      name: partnerName,
      email: partnerEmail,
      phone: partnerChannel || 'Social / Affiliate',
      serviceInterest: '40% Recurring Affiliate Partner Program',
      message: `Promotional Channel: ${partnerChannel}. Requested 40% recurring affiliate tracking link.`,
      source: 'affiliate',
      value: 0,
    });

    setJoined(true);
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(sampleAffiliateLink);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg rounded-2xl bg-[#0d1320] border border-white/10 shadow-2xl p-6 sm:p-8 overflow-hidden">
        
        {/* Close Button */}
        <button
          onClick={() => {
            setAffiliateModalOpen(false);
            setJoined(false);
          }}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white rounded-lg hover:bg-white/5 transition"
        >
          <X className="w-5 h-5" />
        </button>

        {joined ? (
          <div className="text-center py-6 space-y-4">
            <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 mx-auto flex items-center justify-center">
              <CheckCircle2 className="w-10 h-10" />
            </div>
            <h3 className="text-xl font-bold text-white">Welcome to the Partner Network!</h3>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed max-w-sm mx-auto">
              Your application has been registered with Muhammad. You earn <strong>40% lifetime recurring commission</strong> on every user who signs up through your link.
            </p>

            <div className="p-3.5 rounded-xl bg-black/40 border border-white/10 text-left space-y-2">
              <label className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
                Your Exclusive Referral Tracking Link:
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  readOnly
                  value={sampleAffiliateLink}
                  className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-white/10 text-xs text-emerald-400 font-mono"
                />
                <button
                  onClick={handleCopy}
                  className="px-3 py-2 rounded-lg bg-emerald-500 text-slate-950 font-bold text-xs flex items-center gap-1 shrink-0"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>{copied ? 'Copied!' : 'Copy'}</span>
                </button>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-xs text-slate-300 text-left">
              💰 <strong>Monthly Earning Example:</strong> 50 Pro Plan users = 50 × ($79 × 40%) = <strong>$1,580 USD / month (Rs. 4.3+ Lakhs PKR)</strong> passive income sent directly to your bank/crypto.
            </div>

            <button
              onClick={() => setAffiliateModalOpen(false)}
              className="w-full py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs transition"
            >
              Done
            </button>
          </div>
        ) : (
          <div>
            <div className="mb-6">
              <div className="inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-400 bg-emerald-500/10 px-2.5 py-0.5 rounded-full mb-2">
                <TrendingUp className="w-3.5 h-3.5" />
                <span>40% Lifetime Recurring Commissions</span>
              </div>
              <h3 className="text-xl font-extrabold text-white">
                Join the NexusScale AI Affiliate Partner Program
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                Monetize your audience, agency clients, or social presence. We pay commissions on the 1st of every month via Bank Wire, PayPal, EasyPaisa, or USDT.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-3 mb-5">
              <div className="p-3 rounded-xl bg-black/40 border border-white/5">
                <span className="text-xs text-slate-400">Commission Rate</span>
                <p className="text-xl font-black text-emerald-400">40% Recurring</p>
                <span className="text-[10px] text-slate-500">Every single month</span>
              </div>
              <div className="p-3 rounded-xl bg-black/40 border border-white/5">
                <span className="text-xs text-slate-400">Cookie Window</span>
                <p className="text-xl font-black text-cyan-400">90 Days</p>
                <span className="text-[10px] text-slate-500">Industry-leading attribution</span>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-3.5">
              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">
                  Your Full Name:
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Bilal Ahmed"
                  value={partnerName}
                  onChange={(e) => setPartnerName(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-white/10 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">
                  Email Address for Payouts:
                </label>
                <input
                  type="email"
                  required
                  placeholder="name@email.com"
                  value={partnerEmail}
                  onChange={(e) => setPartnerEmail(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-white/10 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">
                  Where will you share it? (YouTube, TikTok, Agency, Blog, WhatsApp):
                </label>
                <input
                  type="text"
                  placeholder="e.g. YouTube Tech Channel / Agency Network"
                  value={partnerChannel}
                  onChange={(e) => setPartnerChannel(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-white/10 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition"
                />
              </div>

              <button
                type="submit"
                className="w-full mt-2 py-3.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-sm shadow-lg shadow-emerald-500/20 transition flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Generate My 40% Partner Link</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          </div>
        )}

      </div>
    </div>
  );
};
