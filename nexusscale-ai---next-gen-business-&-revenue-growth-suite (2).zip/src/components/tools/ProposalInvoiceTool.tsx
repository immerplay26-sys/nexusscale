import React, { useState } from 'react';
import { generateClientProposal } from '../../services/aiGenerator';
import { FileText, Copy, Check, Sparkles, Download, ArrowLeft, Printer } from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const ProposalInvoiceTool: React.FC = () => {
  const { setActiveTab } = useApp();
  const [clientName, setClientName] = useState('Jonathan Miller');
  const [companyName, setCompanyName] = useState('Apex Digital Media LLC');
  const [serviceTitle, setServiceTitle] = useState('AI Growth Engine & B2B Pipeline Infrastructure');
  const [investmentAmount, setInvestmentAmount] = useState('$4,500 USD (Fixed Engagement)');
  const [timeline, setTimeline] = useState('30 Days from Contract Execution');
  const [deliverables, setDeliverables] = useState(
    'Full setup of automated viral content pipeline\nDeployment of 3 personalized B2B outreach sequences\nProgrammatic SEO schema & landing page framework\nBi-weekly growth sprint calls with Muhammad'
  );
  const [terms, setTerms] = useState('50% deposit upon signing, 50% upon milestone completion');
  const [output, setOutput] = useState<string>('');
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const items = deliverables.split('\n').filter((d) => d.trim().length > 0);
      const res = await generateClientProposal({
        clientName,
        companyName,
        serviceTitle,
        investmentAmount,
        timeline,
        deliverables: items,
        terms,
      });
      setOutput(res);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = () => {
    if (!output) return;
    navigator.clipboard.writeText(output);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="py-8 md:py-14 max-w-6xl mx-auto px-4 sm:px-6">
      {/* Back Button */}
      <div className="mb-6 flex items-center justify-between no-print">
        <button
          onClick={() => setActiveTab('home')}
          className="inline-flex items-center gap-2 text-xs font-semibold text-slate-400 hover:text-white transition"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Home</span>
        </button>
        <span className="text-xs font-semibold text-rose-400 bg-rose-500/10 px-2.5 py-1 rounded-full border border-rose-500/20">
          📄 Client Deal & Proposal Generator
        </span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Form Inputs (5 cols) */}
        <div className="lg:col-span-5 p-6 rounded-2xl bg-[#0d1320] border border-white/5 space-y-4 no-print">
          <div>
            <h2 className="text-xl font-extrabold text-white flex items-center gap-2">
              <FileText className="w-5 h-5 text-rose-400" />
              <span>Deal Proposal Creator</span>
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              Produce legally structured, executive Statement of Work (SOW) client agreements ready to print or sign.
            </p>
          </div>

          <form onSubmit={handleGenerate} className="space-y-4">
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">Client Contact Name:</label>
                <input
                  type="text"
                  required
                  value={clientName}
                  onChange={(e) => setClientName(e.target.value)}
                  placeholder="e.g. Jonathan Miller"
                  className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-white/10 text-xs text-white"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">Client Company:</label>
                <input
                  type="text"
                  required
                  value={companyName}
                  onChange={(e) => setCompanyName(e.target.value)}
                  placeholder="e.g. Apex Media LLC"
                  className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-white/10 text-xs text-white"
                />
              </div>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">Service Title / Scope:</label>
              <input
                type="text"
                required
                value={serviceTitle}
                onChange={(e) => setServiceTitle(e.target.value)}
                placeholder="e.g. AI Growth Engine & Pipeline Setup"
                className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-white/10 text-xs text-white"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">Investment Amount ($):</label>
                <input
                  type="text"
                  required
                  value={investmentAmount}
                  onChange={(e) => setInvestmentAmount(e.target.value)}
                  placeholder="e.g. $4,500 USD"
                  className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-white/10 text-xs text-white"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">Timeline:</label>
                <input
                  type="text"
                  required
                  value={timeline}
                  onChange={(e) => setTimeline(e.target.value)}
                  placeholder="e.g. 30 Days"
                  className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-white/10 text-xs text-white"
                />
              </div>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">Deliverables (one per line):</label>
              <textarea
                required
                rows={3}
                value={deliverables}
                onChange={(e) => setDeliverables(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-white/10 text-xs text-white resize-none"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">Payment Terms:</label>
              <input
                type="text"
                required
                value={terms}
                onChange={(e) => setTerms(e.target.value)}
                placeholder="e.g. 50% deposit, 50% on completion"
                className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-white/10 text-xs text-white"
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-rose-500 to-pink-600 hover:from-rose-400 hover:to-pink-500 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-rose-500/20 transition cursor-pointer"
            >
              <Sparkles className="w-4 h-4" />
              <span>Generate Contract Agreement</span>
            </button>
          </form>
        </div>

        {/* Results Workspace (7 cols) */}
        <div className="lg:col-span-7 p-6 rounded-2xl bg-[#090d15] border border-white/5 shadow-2xl min-h-[500px] flex flex-col justify-between print:border-none print:shadow-none print:bg-white print:p-0">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-white/5 mb-4 no-print">
              <span className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                Client Agreement Preview
              </span>
              {output && (
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleCopy}
                    className="px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 text-xs flex items-center gap-1 transition"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copied ? 'Copied' : 'Copy'}</span>
                  </button>
                  <button
                    onClick={handlePrint}
                    className="px-2.5 py-1 rounded-lg bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500/30 text-xs flex items-center gap-1 transition font-bold"
                  >
                    <Printer className="w-3.5 h-3.5" />
                    <span>Print / Save PDF</span>
                  </button>
                </div>
              )}
            </div>

            {output ? (
              <div className="prose prose-invert max-w-none text-xs sm:text-sm text-slate-200 leading-relaxed font-mono whitespace-pre-wrap bg-black/40 p-5 rounded-xl border border-white/5 overflow-x-auto max-h-[550px] overflow-y-auto print:bg-white print:text-black print:border-none print:max-h-none">
                {output}
              </div>
            ) : (
              <div className="py-24 text-center space-y-3 no-print">
                <div className="w-12 h-12 rounded-xl bg-rose-500/10 text-rose-400 mx-auto flex items-center justify-center">
                  <FileText className="w-6 h-6" />
                </div>
                <h4 className="text-sm font-bold text-white">Deal Closer Workspace Ready</h4>
                <p className="text-xs text-slate-400 max-w-sm mx-auto">
                  Click generate to create an executive Statement of Work (SOW) agreement that you can print, sign, or export to PDF for clients.
                </p>
              </div>
            )}
          </div>

          <div className="pt-4 border-t border-white/5 flex items-center justify-between text-[11px] text-slate-500 no-print">
            <span>Legally Structured Commercial Agreement</span>
            <span>Founder: Muhammad (+923199389323)</span>
          </div>
        </div>
      </div>
    </div>
  );
};
