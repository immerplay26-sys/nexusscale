import React, { useState } from 'react';
import { generateOutreachEmails } from '../../services/aiGenerator';
import { Send, Copy, Check, Sparkles, Download, ArrowLeft, RefreshCw, Mail } from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const HighTicketOutreachTool: React.FC = () => {
  const { setActiveTab } = useApp();
  const [targetNiche, setTargetNiche] = useState('Dental Clinics & Orthodontists');
  const [offerService, setOfferService] = useState('High-Converting Patient Booking Engine & Local Google Ranking');
  const [pricePoint, setPricePoint] = useState('$2,500/month retainer');
  const [prospectPainPoint, setProspectPainPoint] = useState('Empty chairs on weekdays and wasted $3k/mo on bad Facebook ads');
  const [senderName, setSenderName] = useState('Muhammad');
  const [output, setOutput] = useState<string>('');
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await generateOutreachEmails({
        targetNiche,
        offerService,
        pricePoint,
        prospectPainPoint,
        senderName,
      });
      setOutput(res);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = () => {
    if (!output) return;
    navigator.clipboard.writeText(output);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    if (!output) return;
    const blob = new Blob([output], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `b2b-outreach-${targetNiche.toLowerCase().replace(/\s+/g, '-')}.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="py-8 md:py-14 max-w-6xl mx-auto px-4 sm:px-6">
      {/* Back Button */}
      <div className="mb-6 flex items-center justify-between">
        <button
          onClick={() => setActiveTab('home')}
          className="inline-flex items-center gap-2 text-xs font-semibold text-slate-400 hover:text-white transition"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Home</span>
        </button>
        <span className="text-xs font-semibold text-emerald-400 bg-emerald-500/10 px-2.5 py-1 rounded-full border border-emerald-500/20">
          🎯 High-Ticket B2B Deal Closer
        </span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Form Inputs (5 cols) */}
        <div className="lg:col-span-5 p-6 rounded-2xl bg-[#0d1320] border border-white/5 space-y-4">
          <div>
            <h2 className="text-xl font-extrabold text-white flex items-center gap-2">
              <Send className="w-5 h-5 text-emerald-400" />
              <span>B2B Outreach Suite</span>
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              Close $3k–$10k client retainers with non-spammy, high-converting cold email sequences and objection responses.
            </p>
          </div>

          <form onSubmit={handleGenerate} className="space-y-4">
            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">Target Client Niche:</label>
              <input
                type="text"
                required
                value={targetNiche}
                onChange={(e) => setTargetNiche(e.target.value)}
                placeholder="e.g. Solar Companies, SaaS Founders"
                className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-white/10 text-xs text-white"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">Your High-Ticket Service / Offer:</label>
              <input
                type="text"
                required
                value={offerService}
                onChange={(e) => setOfferService(e.target.value)}
                placeholder="e.g. Full-Funnel SEO & Paid Acquisition"
                className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-white/10 text-xs text-white"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">Price Point / Retainer:</label>
                <input
                  type="text"
                  required
                  value={pricePoint}
                  onChange={(e) => setPricePoint(e.target.value)}
                  placeholder="e.g. $3,000/mo"
                  className="w-full px-2.5 py-2 rounded-xl bg-slate-900 border border-white/10 text-xs text-white"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">Sender Name:</label>
                <input
                  type="text"
                  required
                  value={senderName}
                  onChange={(e) => setSenderName(e.target.value)}
                  placeholder="e.g. Muhammad"
                  className="w-full px-2.5 py-2 rounded-xl bg-slate-900 border border-white/10 text-xs text-white"
                />
              </div>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">Prospect's Core Pain Point / Bottleneck:</label>
              <textarea
                required
                rows={2}
                value={prospectPainPoint}
                onChange={(e) => setProspectPainPoint(e.target.value)}
                placeholder="e.g. Inconsistent pipeline, unbooked calendar, high client churn"
                className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-white/10 text-xs text-white resize-none"
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20 transition cursor-pointer"
            >
              {loading ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Drafting Sequences & Scripts...</span>
                </>
              ) : (
                <>
                  <Mail className="w-4 h-4" />
                  <span>Generate Outreach & Closer Kit</span>
                </>
              )}
            </button>
          </form>
        </div>

        {/* Results Workspace (7 cols) */}
        <div className="lg:col-span-7 p-6 rounded-2xl bg-[#090d15] border border-white/5 shadow-2xl min-h-[500px] flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-white/5 mb-4">
              <span className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                Outreach Sequence & Battlecard
              </span>
              {output && (
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleCopy}
                    className="px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 text-xs flex items-center gap-1 transition"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copied ? 'Copied' : 'Copy'}</span>
                  </button>
                  <button
                    onClick={handleDownload}
                    className="px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 text-xs flex items-center gap-1 transition"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download</span>
                  </button>
                </div>
              )}
            </div>

            {loading ? (
              <div className="py-24 text-center space-y-3">
                <RefreshCw className="w-8 h-8 text-emerald-500 animate-spin mx-auto" />
                <p className="text-xs text-slate-400">
                  Synthesizing psychological value triggers for {targetNiche}...
                </p>
              </div>
            ) : output ? (
              <div className="prose prose-invert max-w-none text-xs sm:text-sm text-slate-200 leading-relaxed font-mono whitespace-pre-wrap bg-black/40 p-4 rounded-xl border border-white/5 overflow-x-auto max-h-[550px] overflow-y-auto">
                {output}
              </div>
            ) : (
              <div className="py-24 text-center space-y-3">
                <div className="w-12 h-12 rounded-xl bg-emerald-500/10 text-emerald-400 mx-auto flex items-center justify-center">
                  <Send className="w-6 h-6" />
                </div>
                <h4 className="text-sm font-bold text-white">Outreach Closer Workspace Ready</h4>
                <p className="text-xs text-slate-400 max-w-sm mx-auto">
                  Generate 3 battle-tested cold emails, a high-converting LinkedIn note, and objection handling scripts to land high-paying clients.
                </p>
              </div>
            )}
          </div>

          <div className="pt-4 border-t border-white/5 flex items-center justify-between text-[11px] text-slate-500">
            <span>High Reply Rate Optimization</span>
            <span>Commercial B2B Use</span>
          </div>
        </div>
      </div>
    </div>
  );
};
