import React, { useState } from 'react';
import { generateProgrammaticSEO } from '../../services/aiGenerator';
import { Search, Copy, Check, Sparkles, Download, ArrowLeft, RefreshCw, Globe } from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const ProgrammaticSEOTool: React.FC = () => {
  const { setActiveTab } = useApp();
  const [seedKeyword, setSeedKeyword] = useState('AI Accounting Software for Freelancers');
  const [targetMarket, setTargetMarket] = useState('US & UK Digital Agencies');
  const [searchIntent, setSearchIntent] = useState<'Commercial' | 'Informational' | 'Transactional' | 'Navigational'>('Commercial');
  const [output, setOutput] = useState<string>('');
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await generateProgrammaticSEO({
        seedKeyword,
        targetMarket,
        searchIntent,
      });
      setOutput(res);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = () => {
    if (!output) return;
    navigator.clipboard.writeText(output);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    if (!output) return;
    const blob = new Blob([output], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `seo-blueprint-${seedKeyword.toLowerCase().replace(/[^a-z0-9]+/g, '-')}.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="py-8 md:py-14 max-w-6xl mx-auto px-4 sm:px-6">
      {/* Back Button */}
      <div className="mb-6 flex items-center justify-between">
        <button
          onClick={() => setActiveTab('home')}
          className="inline-flex items-center gap-2 text-xs font-semibold text-slate-400 hover:text-white transition"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Home</span>
        </button>
        <span className="text-xs font-semibold text-cyan-400 bg-cyan-500/10 px-2.5 py-1 rounded-full border border-cyan-500/20">
          🌐 Programmatic SEO & Keyword Intel
        </span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Form Inputs (5 cols) */}
        <div className="lg:col-span-5 p-6 rounded-2xl bg-[#0d1320] border border-white/5 space-y-4">
          <div>
            <h2 className="text-xl font-extrabold text-white flex items-center gap-2">
              <Search className="w-5 h-5 text-cyan-400" />
              <span>Programmatic SEO Engine</span>
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              Extract high-intent buyer keywords, SERP-optimized title/meta tags, content hierarchies, and rich FAQ schema.
            </p>
          </div>

          <form onSubmit={handleGenerate} className="space-y-4">
            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">Seed Keyword or Topic:</label>
              <input
                type="text"
                required
                value={seedKeyword}
                onChange={(e) => setSeedKeyword(e.target.value)}
                placeholder="e.g. Best CRM for Shopify Stores"
                className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-white/10 text-xs text-white"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">Target Geographic Market / Audience:</label>
              <input
                type="text"
                required
                value={targetMarket}
                onChange={(e) => setTargetMarket(e.target.value)}
                placeholder="e.g. North America, Global E-com Brands"
                className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-white/10 text-xs text-white"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">Primary Search Intent:</label>
              <select
                value={searchIntent}
                onChange={(e: any) => setSearchIntent(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-white/10 text-xs text-white"
              >
                <option value="Commercial">Commercial (High Buyer Intent)</option>
                <option value="Transactional">Transactional (Ready to Buy / Sign Up)</option>
                <option value="Informational">Informational (High Traffic / Top of Funnel)</option>
                <option value="Navigational">Navigational (Brand vs Competitor)</option>
              </select>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-cyan-500/20 transition cursor-pointer"
            >
              {loading ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Scanning SERP & Intent Clusters...</span>
                </>
              ) : (
                <>
                  <Globe className="w-4 h-4" />
                  <span>Generate Full SEO Architecture</span>
                </>
              )}
            </button>
          </form>
        </div>

        {/* Results Workspace (7 cols) */}
        <div className="lg:col-span-7 p-6 rounded-2xl bg-[#090d15] border border-white/5 shadow-2xl min-h-[500px] flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-white/5 mb-4">
              <span className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                SEO Strategy & Structured Schema
              </span>
              {output && (
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleCopy}
                    className="px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 text-xs flex items-center gap-1 transition"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-cyan-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copied ? 'Copied' : 'Copy'}</span>
                  </button>
                  <button
                    onClick={handleDownload}
                    className="px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 text-xs flex items-center gap-1 transition"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download</span>
                  </button>
                </div>
              )}
            </div>

            {loading ? (
              <div className="py-24 text-center space-y-3">
                <RefreshCw className="w-8 h-8 text-cyan-400 animate-spin mx-auto" />
                <p className="text-xs text-slate-400">
                  Calculating search volume, keyword difficulty, and JSON-LD schema...
                </p>
              </div>
            ) : output ? (
              <div className="prose prose-invert max-w-none text-xs sm:text-sm text-slate-200 leading-relaxed font-mono whitespace-pre-wrap bg-black/40 p-4 rounded-xl border border-white/5 overflow-x-auto max-h-[550px] overflow-y-auto">
                {output}
              </div>
            ) : (
              <div className="py-24 text-center space-y-3">
                <div className="w-12 h-12 rounded-xl bg-cyan-500/10 text-cyan-400 mx-auto flex items-center justify-center">
                  <Search className="w-6 h-6" />
                </div>
                <h4 className="text-sm font-bold text-white">SEO Architecture Generator</h4>
                <p className="text-xs text-slate-400 max-w-sm mx-auto">
                  Enter your topic to generate long-tail keywords, SERP meta tags, article blueprints, and valid FAQ schema.
                </p>
              </div>
            )}
          </div>

          <div className="pt-4 border-t border-white/5 flex items-center justify-between text-[11px] text-slate-500">
            <span>Google 2026 Core Algorithm Ready</span>
            <span>Schema.org Validated</span>
          </div>
        </div>
      </div>
    </div>
  );
};
