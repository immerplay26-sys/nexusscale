import React, { useState } from 'react';
import { generateViralScript } from '../../services/aiGenerator';
import { Flame, Copy, Check, Sparkles, Download, ArrowLeft, RefreshCw } from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const ViralScriptTool: React.FC = () => {
  const { setActiveTab } = useApp();
  const [platform, setPlatform] = useState<'TikTok' | 'Instagram Reels' | 'YouTube Shorts' | 'LinkedIn' | 'X (Twitter)'>('TikTok');
  const [niche, setNiche] = useState('E-commerce & AI Tools');
  const [topic, setTopic] = useState('How dropshippers make $10k/month without holding inventory');
  const [tone, setTone] = useState<'Aggressive Growth' | 'Storytelling' | 'Contrarian' | 'Humorous' | 'Data-Driven'>('Contrarian');
  const [targetAudience, setTargetAudience] = useState('Gen-Z Creators & Side Hustlers');
  const [output, setOutput] = useState<string>('');
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await generateViralScript({
        platform,
        niche,
        topic,
        tone,
        targetAudience,
      });
      setOutput(res);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = () => {
    if (!output) return;
    navigator.clipboard.writeText(output);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    if (!output) return;
    const blob = new Blob([output], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `viral-${platform.toLowerCase()}-script.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="py-8 md:py-14 max-w-6xl mx-auto px-4 sm:px-6">
      {/* Back Button */}
      <div className="mb-6 flex items-center justify-between">
        <button
          onClick={() => setActiveTab('home')}
          className="inline-flex items-center gap-2 text-xs font-semibold text-slate-400 hover:text-white transition"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Home</span>
        </button>
        <span className="text-xs font-semibold text-emerald-400 bg-emerald-500/10 px-2.5 py-1 rounded-full border border-emerald-500/20">
          🔥 Viral Hook & Script Engine
        </span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Form Inputs (5 cols) */}
        <div className="lg:col-span-5 p-6 rounded-2xl bg-[#0d1320] border border-white/5 space-y-4">
          <div>
            <h2 className="text-xl font-extrabold text-white flex items-center gap-2">
              <Flame className="w-5 h-5 text-amber-500" />
              <span>Viral Video Generator</span>
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              Create retention-optimized hooks and second-by-second scripts with B-roll audio/visual directions.
            </p>
          </div>

          <form onSubmit={handleGenerate} className="space-y-4">
            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">Target Platform:</label>
              <select
                value={platform}
                onChange={(e: any) => setPlatform(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-white/10 text-xs text-white"
              >
                <option value="TikTok">TikTok (High Virality)</option>
                <option value="Instagram Reels">Instagram Reels (High Conversion)</option>
                <option value="YouTube Shorts">YouTube Shorts (Search & Evergreen)</option>
                <option value="LinkedIn">LinkedIn Video (B2B Authority)</option>
                <option value="X (Twitter)">X / Twitter Video (Tech & Hustle)</option>
              </select>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">Industry / Niche:</label>
              <input
                type="text"
                required
                value={niche}
                onChange={(e) => setNiche(e.target.value)}
                placeholder="e.g. Real Estate, Fitness, Dropshipping"
                className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-white/10 text-xs text-white"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">Video Core Topic or Secret:</label>
              <input
                type="text"
                required
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                placeholder="e.g. 3 AI prompts that replace a $4k copywriter"
                className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-white/10 text-xs text-white"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">Psychological Tone:</label>
                <select
                  value={tone}
                  onChange={(e: any) => setTone(e.target.value)}
                  className="w-full px-2.5 py-2 rounded-xl bg-slate-900 border border-white/10 text-xs text-white"
                >
                  <option value="Contrarian">Contrarian</option>
                  <option value="Aggressive Growth">Aggressive Growth</option>
                  <option value="Storytelling">Storytelling</option>
                  <option value="Data-Driven">Data-Driven</option>
                  <option value="Humorous">Humorous</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">Target Audience:</label>
                <input
                  type="text"
                  required
                  value={targetAudience}
                  onChange={(e) => setTargetAudience(e.target.value)}
                  placeholder="e.g. Freelancers, Agency owners"
                  className="w-full px-2.5 py-2 rounded-xl bg-slate-900 border border-white/10 text-xs text-white"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-400 hover:to-orange-500 text-slate-950 font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-orange-500/20 transition cursor-pointer"
            >
              {loading ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Synthesizing Viral Hooks...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Generate Full Viral Package</span>
                </>
              )}
            </button>
          </form>
        </div>

        {/* Results Workspace (7 cols) */}
        <div className="lg:col-span-7 p-6 rounded-2xl bg-[#090d15] border border-white/5 shadow-2xl min-h-[500px] flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-white/5 mb-4">
              <span className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                Generated Script & Blueprint
              </span>
              {output && (
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleCopy}
                    className="px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 text-xs flex items-center gap-1 transition"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copied ? 'Copied' : 'Copy'}</span>
                  </button>
                  <button
                    onClick={handleDownload}
                    className="px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 text-xs flex items-center gap-1 transition"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download</span>
                  </button>
                </div>
              )}
            </div>

            {loading ? (
              <div className="py-24 text-center space-y-3">
                <RefreshCw className="w-8 h-8 text-amber-500 animate-spin mx-auto" />
                <p className="text-xs text-slate-400">
                  Analyzing top viral formats for {platform}... optimizing hook drop rate...
                </p>
              </div>
            ) : output ? (
              <div className="prose prose-invert max-w-none text-xs sm:text-sm text-slate-200 leading-relaxed font-mono whitespace-pre-wrap bg-black/40 p-4 rounded-xl border border-white/5 overflow-x-auto max-h-[550px] overflow-y-auto">
                {output}
              </div>
            ) : (
              <div className="py-24 text-center space-y-3">
                <div className="w-12 h-12 rounded-xl bg-amber-500/10 text-amber-400 mx-auto flex items-center justify-center">
                  <Flame className="w-6 h-6" />
                </div>
                <h4 className="text-sm font-bold text-white">Your Script Studio is Ready</h4>
                <p className="text-xs text-slate-400 max-w-sm mx-auto">
                  Click the button on the left to instantly generate 3 high-converting viral hooks, a timed 60-second video script, and high-CTR thumbnail concept.
                </p>
              </div>
            )}
          </div>

          <div className="pt-4 border-t border-white/5 flex items-center justify-between text-[11px] text-slate-500">
            <span>Retention Optimized for {platform}</span>
            <span>Commercial License: Full Ownership</span>
          </div>
        </div>
      </div>
    </div>
  );
};
