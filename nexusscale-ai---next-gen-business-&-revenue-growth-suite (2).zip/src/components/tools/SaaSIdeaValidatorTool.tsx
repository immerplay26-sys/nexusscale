import React, { useState } from 'react';
import { generateSaaSValidation } from '../../services/aiGenerator';
import { Rocket, Copy, Check, Sparkles, Download, ArrowLeft, RefreshCw, TrendingUp } from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const SaaSIdeaValidatorTool: React.FC = () => {
  const { setActiveTab } = useApp();
  const [ideaName, setIdeaName] = useState('LeadSprint AI');
  const [problemSolved, setProblemSolved] = useState('Real estate brokers waste 4 hours daily manually calling cold MLS expired listings with 95% voicemail rates');
  const [targetUser, setTargetUser] = useState('High-volume residential real estate agents & brokers');
  const [budgetOrTimeline, setBudgetOrTimeline] = useState('14-day launch sprint, $500 bootstrap budget');
  const [output, setOutput] = useState<string>('');
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await generateSaaSValidation({
        ideaName,
        problemSolved,
        targetUser,
        budgetOrTimeline,
      });
      setOutput(res);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = () => {
    if (!output) return;
    navigator.clipboard.writeText(output);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    if (!output) return;
    const blob = new Blob([output], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `saas-validation-${ideaName.toLowerCase().replace(/\s+/g, '-')}.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="py-8 md:py-14 max-w-6xl mx-auto px-4 sm:px-6">
      {/* Back Button */}
      <div className="mb-6 flex items-center justify-between">
        <button
          onClick={() => setActiveTab('home')}
          className="inline-flex items-center gap-2 text-xs font-semibold text-slate-400 hover:text-white transition"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Home</span>
        </button>
        <span className="text-xs font-semibold text-purple-400 bg-purple-500/10 px-2.5 py-1 rounded-full border border-purple-500/20">
          🚀 Micro-SaaS & Idea Validator
        </span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Form Inputs (5 cols) */}
        <div className="lg:col-span-5 p-6 rounded-2xl bg-[#0d1320] border border-white/5 space-y-4">
          <div>
            <h2 className="text-xl font-extrabold text-white flex items-center gap-2">
              <Rocket className="w-5 h-5 text-purple-400" />
              <span>Venture Validator</span>
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              Validate business viability, estimate Total Addressable Market (TAM), determine optimal pricing, and get a 30-day MVP roadmap.
            </p>
          </div>

          <form onSubmit={handleGenerate} className="space-y-4">
            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">Venture / Software Name:</label>
              <input
                type="text"
                required
                value={ideaName}
                onChange={(e) => setIdeaName(e.target.value)}
                placeholder="e.g. LeadSprint AI"
                className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-white/10 text-xs text-white"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">Target Customer / ICP:</label>
              <input
                type="text"
                required
                value={targetUser}
                onChange={(e) => setTargetUser(e.target.value)}
                placeholder="e.g. E-commerce founders doing $50k+/mo"
                className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-white/10 text-xs text-white"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">Core Pain Point / Problem Solved:</label>
              <textarea
                required
                rows={3}
                value={problemSolved}
                onChange={(e) => setProblemSolved(e.target.value)}
                placeholder="Describe the urgent problem they will pay money to eliminate..."
                className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-white/10 text-xs text-white resize-none"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">Budget / Timeline Constraints:</label>
              <input
                type="text"
                required
                value={budgetOrTimeline}
                onChange={(e) => setBudgetOrTimeline(e.target.value)}
                placeholder="e.g. 14 days, $300 bootstrap"
                className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-white/10 text-xs text-white"
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-purple-500 to-indigo-600 hover:from-purple-400 hover:to-indigo-500 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-purple-500/20 transition cursor-pointer"
            >
              {loading ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Evaluating Market Viability...</span>
                </>
              ) : (
                <>
                  <TrendingUp className="w-4 h-4" />
                  <span>Validate Idea & Build Roadmap</span>
                </>
              )}
            </button>
          </form>
        </div>

        {/* Results Workspace (7 cols) */}
        <div className="lg:col-span-7 p-6 rounded-2xl bg-[#090d15] border border-white/5 shadow-2xl min-h-[500px] flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-white/5 mb-4">
              <span className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                Venture Viability & GTM Blueprint
              </span>
              {output && (
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleCopy}
                    className="px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 text-xs flex items-center gap-1 transition"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-purple-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copied ? 'Copied' : 'Copy'}</span>
                  </button>
                  <button
                    onClick={handleDownload}
                    className="px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 text-xs flex items-center gap-1 transition"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download</span>
                  </button>
                </div>
              )}
            </div>

            {loading ? (
              <div className="py-24 text-center space-y-3">
                <RefreshCw className="w-8 h-8 text-purple-400 animate-spin mx-auto" />
                <p className="text-xs text-slate-400">
                  Modeling TAM, competitor moats, pricing tiers, and 30-day sprint...
                </p>
              </div>
            ) : output ? (
              <div className="prose prose-invert max-w-none text-xs sm:text-sm text-slate-200 leading-relaxed font-mono whitespace-pre-wrap bg-black/40 p-4 rounded-xl border border-white/5 overflow-x-auto max-h-[550px] overflow-y-auto">
                {output}
              </div>
            ) : (
              <div className="py-24 text-center space-y-3">
                <div className="w-12 h-12 rounded-xl bg-purple-500/10 text-purple-400 mx-auto flex items-center justify-center">
                  <Rocket className="w-6 h-6" />
                </div>
                <h4 className="text-sm font-bold text-white">Venture Validator Ready</h4>
                <p className="text-xs text-slate-400 max-w-sm mx-auto">
                  Test your product idea to get objective viability scores, target market numbers, pricing strategies, and an actionable 30-day sprint.
                </p>
              </div>
            )}
          </div>

          <div className="pt-4 border-t border-white/5 flex items-center justify-between text-[11px] text-slate-500">
            <span>Algorithmic Market Intelligence</span>
            <span>Venture Capital Tested Format</span>
          </div>
        </div>
      </div>
    </div>
  );
};
