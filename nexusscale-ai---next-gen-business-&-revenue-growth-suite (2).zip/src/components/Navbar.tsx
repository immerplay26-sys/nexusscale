import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  Sparkles, 
  Flame, 
  Send, 
  Search, 
  Rocket, 
  FileText, 
  Calculator, 
  ShieldCheck, 
  Menu, 
  X, 
  Lock,
  ChevronDown,
  DollarSign
} from 'lucide-react';
import { ActiveTab } from '../types';

export const Navbar: React.FC = () => {
  const { 
    settings, 
    activeTab, 
    setActiveTab, 
    isAdminLoggedIn, 
    setCheckoutModalOpen,
    setSelectedPlan 
  } = useApp();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [toolsDropdownOpen, setToolsDropdownOpen] = useState(false);

  const navLinks: { label: string; tab: ActiveTab; icon?: any }[] = [
    { label: 'Home', tab: 'home' },
    { label: 'ROI Calculator', tab: 'roi', icon: Calculator },
    { label: 'Pricing Plans', tab: 'pricing', icon: DollarSign },
    { label: 'About Story', tab: 'about' },
    { label: 'Contact & Support', tab: 'contact' },
  ];

  const toolsList: { label: string; tab: ActiveTab; desc: string; icon: any }[] = [
    { label: 'Viral Hook & Script Studio', tab: 'viral-tool', desc: 'Craft viral TikTok/Reels scripts with 98% retention', icon: Flame },
    { label: 'High-Ticket B2B Outreach Closer', tab: 'outreach-tool', desc: 'Cold emails & pitches closing $3k–$10k deals', icon: Send },
    { label: 'Programmatic SEO & Keywords', tab: 'seo-tool', desc: 'Find high-intent ranking keywords and schemas', icon: Search },
    { label: 'Micro-SaaS & Idea Validator', tab: 'validator-tool', desc: 'TAM, pricing, and 30-day MVP launch roadmap', icon: Rocket },
    { label: 'Contract & Proposal Generator', tab: 'proposal-tool', desc: 'Printable professional client deals & invoices', icon: FileText },
  ];

  const handleNavClick = (tab: ActiveTab) => {
    setActiveTab(tab);
    setMobileMenuOpen(false);
    setToolsDropdownOpen(false);
  };

  return (
    <header className="sticky top-0 z-50 w-full backdrop-blur-md bg-[#080b11]/90 border-b border-white/5 transition-all">
      {/* Top Announcement Bar */}
      {settings.showAnnouncement && (
        <div className="bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-600 py-1.5 px-4 text-center text-xs font-semibold text-white tracking-wide shadow-sm flex items-center justify-center gap-2">
          <span>{settings.announcementText}</span>
          <button 
            onClick={() => {
              setSelectedPlan('Pro');
              setCheckoutModalOpen(true);
            }}
            className="underline underline-offset-2 hover:opacity-90 transition font-bold"
          >
            Claim 60% Off →
          </button>
        </div>
      )}

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 md:h-18">
          
          {/* Brand Logo */}
          <div 
            onClick={() => handleNavClick('home')}
            className="flex items-center gap-2.5 cursor-pointer group"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-cyan-600 p-0.5 shadow-lg shadow-emerald-500/20 group-hover:scale-105 transition-transform duration-200">
              <div className="w-full h-full bg-[#090e17] rounded-[10px] flex items-center justify-center">
                <Sparkles className="w-5 h-5 text-emerald-400 group-hover:rotate-12 transition-transform duration-300" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-xl tracking-tight text-white group-hover:text-emerald-300 transition-colors">
                  {settings.siteName}
                </span>
                <span className="text-[10px] font-mono tracking-wider px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                  PRO
                </span>
              </div>
              <p className="text-[11px] text-slate-400 font-medium hidden sm:block">
                Global Revenue Growth Engine
              </p>
            </div>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-1.5 xl:gap-2">
            <button
              onClick={() => handleNavClick('home')}
              className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                activeTab === 'home' 
                  ? 'text-emerald-400 bg-emerald-500/10' 
                  : 'text-slate-300 hover:text-white hover:bg-white/5'
              }`}
            >
              Home
            </button>

            {/* Tools Dropdown */}
            <div className="relative">
              <button
                onClick={() => setToolsDropdownOpen(!toolsDropdownOpen)}
                onMouseEnter={() => setToolsDropdownOpen(true)}
                className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors flex items-center gap-1 ${
                  ['viral-tool', 'outreach-tool', 'seo-tool', 'validator-tool', 'proposal-tool'].includes(activeTab)
                    ? 'text-emerald-400 bg-emerald-500/10'
                    : 'text-slate-300 hover:text-white hover:bg-white/5'
                }`}
              >
                <span>AI Revenue Tools</span>
                <ChevronDown className={`w-4 h-4 transition-transform duration-200 ${toolsDropdownOpen ? 'rotate-180 text-emerald-400' : ''}`} />
              </button>

              {toolsDropdownOpen && (
                <div 
                  onMouseLeave={() => setToolsDropdownOpen(false)}
                  className="absolute left-0 mt-2 w-80 rounded-2xl bg-[#0c121e] border border-white/10 shadow-2xl p-2 z-50 animate-in fade-in slide-in-from-top-2 duration-150 backdrop-blur-xl"
                >
                  <div className="px-3 py-2 border-b border-white/5 mb-1">
                    <p className="text-xs font-semibold uppercase tracking-wider text-slate-400">Integrated Super-Tools</p>
                  </div>
                  {toolsList.map((tool) => {
                    const Icon = tool.icon;
                    return (
                      <button
                        key={tool.tab}
                        onClick={() => handleNavClick(tool.tab)}
                        className={`w-full text-left p-2.5 rounded-xl transition flex items-start gap-3 ${
                          activeTab === tool.tab 
                            ? 'bg-emerald-500/15 text-emerald-300' 
                            : 'hover:bg-white/5 text-slate-200'
                        }`}
                      >
                        <div className="w-8 h-8 rounded-lg bg-emerald-500/10 text-emerald-400 flex items-center justify-center shrink-0 mt-0.5">
                          <Icon className="w-4 h-4" />
                        </div>
                        <div>
                          <p className="text-sm font-semibold">{tool.label}</p>
                          <p className="text-xs text-slate-400 leading-snug line-clamp-1">{tool.desc}</p>
                        </div>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>

            {navLinks.slice(1).map((item) => (
              <button
                key={item.tab}
                onClick={() => handleNavClick(item.tab)}
                className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                  activeTab === item.tab
                    ? 'text-emerald-400 bg-emerald-500/10'
                    : 'text-slate-300 hover:text-white hover:bg-white/5'
                }`}
              >
                {item.label}
              </button>
            ))}
          </nav>

          {/* Right Action Buttons */}
          <div className="hidden sm:flex items-center gap-3">
            {/* Admin Portal Shortcut Button */}
            <button
              onClick={() => handleNavClick(isAdminLoggedIn ? 'admin-dashboard' : 'admin-login')}
              title={isAdminLoggedIn ? 'Open Admin Control Hub' : 'Admin Login (/admin-login.html)'}
              className={`p-2 rounded-xl text-xs font-medium border flex items-center gap-1.5 transition ${
                isAdminLoggedIn
                  ? 'border-emerald-500/40 text-emerald-400 bg-emerald-500/10 hover:bg-emerald-500/20'
                  : 'border-white/10 text-slate-400 hover:text-white hover:border-white/20 hover:bg-white/5'
              }`}
            >
              <Lock className="w-3.5 h-3.5" />
              <span className="hidden md:inline">{isAdminLoggedIn ? 'Admin Hub' : 'Admin'}</span>
            </button>

            {/* Direct CTA */}
            <button
              onClick={() => {
                setSelectedPlan('Pro');
                setCheckoutModalOpen(true);
              }}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-bold text-sm shadow-md shadow-emerald-500/20 hover:shadow-emerald-500/30 transition-all active:scale-95"
            >
              Get Instant Access
            </button>
          </div>

          {/* Mobile Menu Toggle */}
          <div className="flex items-center gap-2 lg:hidden">
            <button
              onClick={() => handleNavClick(isAdminLoggedIn ? 'admin-dashboard' : 'admin-login')}
              className="p-2 text-slate-400 hover:text-white"
              title="Admin Login"
            >
              <Lock className="w-4 h-4" />
            </button>

            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-slate-400 hover:text-white hover:bg-white/5 rounded-lg"
              aria-label="Toggle Navigation Menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-b border-white/10 bg-[#0c121e] px-4 pt-3 pb-6 space-y-3 animate-in fade-in slide-in-from-top-2 duration-150">
          <div className="space-y-1">
            <button
              onClick={() => handleNavClick('home')}
              className={`w-full text-left px-3 py-2 rounded-lg text-sm font-medium ${
                activeTab === 'home' ? 'text-emerald-400 bg-emerald-500/10' : 'text-slate-300'
              }`}
            >
              Home
            </button>

            <div className="py-1">
              <p className="px-3 text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1">
                AI Revenue Tools
              </p>
              {toolsList.map((tool) => (
                <button
                  key={tool.tab}
                  onClick={() => handleNavClick(tool.tab)}
                  className={`w-full text-left px-3 py-2 rounded-lg text-sm flex items-center gap-2.5 ${
                    activeTab === tool.tab ? 'text-emerald-400 bg-emerald-500/10' : 'text-slate-300 hover:bg-white/5'
                  }`}
                >
                  <tool.icon className="w-4 h-4 text-emerald-400" />
                  <span>{tool.label}</span>
                </button>
              ))}
            </div>

            {navLinks.slice(1).map((item) => (
              <button
                key={item.tab}
                onClick={() => handleNavClick(item.tab)}
                className={`w-full text-left px-3 py-2 rounded-lg text-sm font-medium ${
                  activeTab === item.tab ? 'text-emerald-400 bg-emerald-500/10' : 'text-slate-300'
                }`}
              >
                {item.label}
              </button>
            ))}

            <button
              onClick={() => handleNavClick(isAdminLoggedIn ? 'admin-dashboard' : 'admin-login')}
              className={`w-full text-left px-3 py-2 rounded-lg text-sm font-medium flex items-center gap-2 ${
                ['admin-login', 'admin-dashboard'].includes(activeTab) ? 'text-emerald-400 bg-emerald-500/10' : 'text-slate-300'
              }`}
            >
              <Lock className="w-4 h-4 text-emerald-400" />
              <span>{isAdminLoggedIn ? 'Admin Control Hub' : 'Admin Login (/admin-login.html)'}</span>
            </button>
          </div>

          <div className="pt-2 border-t border-white/5">
            <button
              onClick={() => {
                setSelectedPlan('Pro');
                setCheckoutModalOpen(true);
                setMobileMenuOpen(false);
              }}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 font-bold text-center shadow-lg shadow-emerald-500/20"
            >
              Get Instant Access Now
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
