import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Lock, Mail, Key, ShieldCheck, ArrowRight, AlertCircle, ArrowLeft, CheckCircle2 } from 'lucide-react';

export const AdminLogin: React.FC = () => {
  const { adminLogin, adminCreds, setActiveTab } = useApp();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsSubmitting(true);

    const success = adminLogin(email, password);
    setIsSubmitting(false);

    if (!success) {
      setError('Invalid admin credentials. Please verify your email and password.');
    }
  };

  const handleFillDefault = () => {
    setEmail(adminCreds.email);
    setPassword(adminCreds.password);
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center px-4 py-12">
      <div className="w-full max-w-md p-6 sm:p-8 rounded-2xl bg-[#0d1320] border border-white/10 shadow-2xl relative">
        
        {/* Back Link */}
        <button
          onClick={() => setActiveTab('home')}
          className="inline-flex items-center gap-1.5 text-xs text-slate-400 hover:text-white transition mb-6"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Return to Public Site</span>
        </button>

        {/* Header */}
        <div className="text-center space-y-2 mb-8">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-emerald-500 to-cyan-600 p-0.5 shadow-lg shadow-emerald-500/20 mx-auto flex items-center justify-center">
            <div className="w-full h-full bg-[#090e17] rounded-[14px] flex items-center justify-center">
              <Lock className="w-6 h-6 text-emerald-400" />
            </div>
          </div>
          <h2 className="text-2xl font-extrabold text-white tracking-tight">Admin Gateway</h2>
          <p className="text-xs text-slate-400">
            Sign in to access complete website customization, lead database, and security settings.
          </p>
          <div className="inline-block text-[11px] font-mono text-emerald-400 bg-emerald-500/10 px-2.5 py-0.5 rounded border border-emerald-500/20">
            Path: /admin-login.html
          </div>
        </div>

        {/* Error Alert */}
        {error && (
          <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-300 text-xs flex items-center gap-2 mb-5">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="text-xs font-semibold text-slate-300 block mb-1">
              Admin Email Address:
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="email"
                required
                placeholder="muhammadofficial356@gmail.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full pl-10 pr-3.5 py-2.5 rounded-xl bg-slate-900 border border-white/10 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition"
              />
            </div>
          </div>

          <div>
            <label className="text-xs font-semibold text-slate-300 block mb-1">
              Admin Master Password:
            </label>
            <div className="relative">
              <Key className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="password"
                required
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full pl-10 pr-3.5 py-2.5 rounded-xl bg-slate-900 border border-white/10 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition font-mono"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full py-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-sm shadow-lg shadow-emerald-500/20 transition flex items-center justify-center gap-2 cursor-pointer"
          >
            <span>Access Admin Control Hub</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        {/* Preset Helper for Owner */}
        <div className="mt-6 pt-5 border-t border-white/5 text-center">
          <button
            type="button"
            onClick={handleFillDefault}
            className="text-[11px] text-slate-400 hover:text-emerald-400 transition underline underline-offset-2"
          >
            Owner Quick Autofill (Muhammad: muhammadofficial356@gmail.com)
          </button>
        </div>

        <div className="mt-4 text-[10px] text-center text-slate-400 flex items-center justify-center gap-1.5">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
          <span>Encrypted Session · Owner Authorized Only</span>
        </div>

      </div>
    </div>
  );
};
