import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  Sliders, 
  Users, 
  ShieldCheck, 
  TrendingUp, 
  LogOut, 
  ExternalLink, 
  Sparkles, 
  Check, 
  Lock 
} from 'lucide-react';
import { WebsiteCustomizer } from './WebsiteCustomizer';
import { LeadsManager } from './LeadsManager';
import { SecuritySettings } from './SecuritySettings';
import { RevenueTracker } from './RevenueTracker';

export const AdminDashboard: React.FC = () => {
  const { adminLogout, setActiveTab, settings, adminCreds, leads } = useApp();
  const [activeAdminSubtab, setActiveAdminSubtab] = useState<'overview' | 'leads' | 'customizer' | 'security'>('customizer');

  const unreadCount = leads.filter((l) => l.status === 'new').length;

  return (
    <div className="py-8 md:py-12 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      {/* Top Banner / Breadcrumb */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 rounded-2xl bg-[#0c121e] border border-emerald-500/20 shadow-xl mb-8">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 p-0.5 shadow-md">
            <div className="w-full h-full bg-[#080d16] rounded-[10px] flex items-center justify-center">
              <Lock className="w-5 h-5 text-emerald-400" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-extrabold text-white">Owner Control Center</h2>
              <span className="text-[10px] font-mono bg-emerald-500/10 text-emerald-400 px-2 py-0.5 rounded border border-emerald-500/20">
                ADMIN AUTHENTICATED
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Logged in as: <strong className="text-slate-200">{adminCreds.email}</strong> · Full administrative privileges
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={() => setActiveTab('home')}
            className="px-3.5 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-200 text-xs font-semibold flex items-center gap-1.5 transition border border-white/10"
          >
            <span>View Public Website</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={adminLogout}
            className="px-3.5 py-2 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/20 text-xs font-semibold flex items-center gap-1.5 transition"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Sign Out</span>
          </button>
        </div>
      </div>

      {/* Admin Subtabs Bar */}
      <div className="flex items-center gap-2 p-1.5 bg-[#090d15] rounded-2xl border border-white/10 mb-8 overflow-x-auto">
        <button
          onClick={() => setActiveAdminSubtab('customizer')}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold transition flex items-center gap-2 shrink-0 ${
            activeAdminSubtab === 'customizer'
              ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Sliders className="w-4 h-4" />
          <span>Website Customization Engine</span>
        </button>

        <button
          onClick={() => setActiveAdminSubtab('leads')}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold transition flex items-center gap-2 shrink-0 ${
            activeAdminSubtab === 'leads'
              ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>Client Leads & CRM</span>
          {unreadCount > 0 && (
            <span className="w-5 h-5 rounded-full bg-rose-500 text-white text-[10px] flex items-center justify-center font-mono">
              {unreadCount}
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveAdminSubtab('overview')}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold transition flex items-center gap-2 shrink-0 ${
            activeAdminSubtab === 'overview'
              ? 'bg-purple-500 text-white shadow-md shadow-purple-500/20'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <TrendingUp className="w-4 h-4" />
          <span>Revenue & MRR Monitor</span>
        </button>

        <button
          onClick={() => setActiveAdminSubtab('security')}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold transition flex items-center gap-2 shrink-0 ${
            activeAdminSubtab === 'security'
              ? 'bg-slate-200 text-slate-950 shadow-md'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <ShieldCheck className="w-4 h-4" />
          <span>Security & Credentials</span>
        </button>
      </div>

      {/* Subtab Panels */}
      <div className="bg-[#0c121e] border border-white/10 rounded-2xl p-6 sm:p-8 shadow-2xl">
        {activeAdminSubtab === 'customizer' && <WebsiteCustomizer />}
        {activeAdminSubtab === 'leads' && <LeadsManager />}
        {activeAdminSubtab === 'overview' && <RevenueTracker />}
        {activeAdminSubtab === 'security' && <SecuritySettings />}
      </div>
    </div>
  );
};
