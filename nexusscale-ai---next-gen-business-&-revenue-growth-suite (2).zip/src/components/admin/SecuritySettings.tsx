import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { ShieldCheck, Key, Mail, Check, AlertCircle, Lock } from 'lucide-react';

export const SecuritySettings: React.FC = () => {
  const { adminCreds, updateAdminCredentials } = useApp();
  const [currentEmail, setCurrentEmail] = useState(adminCreds.email);
  const [currentPasswordConfirm, setCurrentPasswordConfirm] = useState('');
  const [newEmail, setNewEmail] = useState(adminCreds.email);
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const handleUpdateCredentials = (e: React.FormEvent) => {
    e.preventDefault();
    setStatusMessage(null);

    // Verify current password first
    if (currentPasswordConfirm !== adminCreds.password) {
      setStatusMessage({
        type: 'error',
        text: 'Current master password entered does not match the active password.',
      });
      return;
    }

    if (newPassword && newPassword !== confirmNewPassword) {
      setStatusMessage({
        type: 'error',
        text: 'New password and confirmation password do not match.',
      });
      return;
    }

    // Apply updates
    const updated = {
      email: newEmail.trim() || adminCreds.email,
      password: newPassword ? newPassword : adminCreds.password,
    };

    updateAdminCredentials(updated);
    setCurrentPasswordConfirm('');
    setNewPassword('');
    setConfirmNewPassword('');
    setStatusMessage({
      type: 'success',
      text: 'Admin credentials updated successfully! You can now log in with your updated email and password.',
    });
  };

  return (
    <div className="max-w-2xl space-y-6">
      <div className="pb-4 border-b border-white/5">
        <h3 className="text-lg font-bold text-white flex items-center gap-2">
          <ShieldCheck className="w-5 h-5 text-emerald-400" />
          <span>Admin Credentials & Security Control</span>
        </h3>
        <p className="text-xs text-slate-400">
          Update the email address and master password used to log in at <code>/admin-login.html</code>.
        </p>
      </div>

      {statusMessage && (
        <div
          className={`p-4 rounded-xl border text-xs flex items-center gap-2 ${
            statusMessage.type === 'success'
              ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
              : 'bg-rose-500/10 border-rose-500/30 text-rose-300'
          }`}
        >
          {statusMessage.type === 'success' ? (
            <Check className="w-4 h-4 shrink-0 text-emerald-400" />
          ) : (
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
          )}
          <span>{statusMessage.text}</span>
        </div>
      )}

      {/* Active Credential Info Box */}
      <div className="p-4 rounded-xl bg-black/40 border border-white/5 space-y-2 text-xs">
        <p className="font-semibold text-white flex items-center gap-1.5">
          <Lock className="w-3.5 h-3.5 text-emerald-400" />
          <span>Currently Active Admin Identity:</span>
        </p>
        <p className="text-slate-300 font-mono">
          Email: <span className="text-emerald-400 font-bold">{adminCreds.email}</span>
        </p>
        <p className="text-slate-400 text-[11px]">
          Password: <code>••••••••</code> (Active in secure local vault)
        </p>
      </div>

      <form onSubmit={handleUpdateCredentials} className="p-6 rounded-2xl bg-[#090d15] border border-white/5 space-y-4">
        <div>
          <label className="text-xs font-semibold text-slate-300 block mb-1">
            New Admin Login Email:
          </label>
          <div className="relative">
            <Mail className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="email"
              required
              value={newEmail}
              onChange={(e) => setNewEmail(e.target.value)}
              className="w-full pl-10 pr-3.5 py-2.5 rounded-xl bg-slate-900 border border-white/10 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
            />
          </div>
        </div>

        <div className="pt-2 border-t border-white/5 space-y-4">
          <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
            Change Master Password (Optional)
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">
                New Password:
              </label>
              <input
                type="password"
                placeholder="Leave blank to keep unchanged"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-white/10 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-emerald-500 font-mono"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">
                Confirm New Password:
              </label>
              <input
                type="password"
                placeholder="Repeat new password"
                value={confirmNewPassword}
                onChange={(e) => setConfirmNewPassword(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-white/10 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-emerald-500 font-mono"
              />
            </div>
          </div>
        </div>

        <div className="pt-3 border-t border-white/5">
          <label className="text-xs font-bold text-amber-400 block mb-1">
            Authorize with Current Master Password:
          </label>
          <div className="relative">
            <Key className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="password"
              required
              placeholder="Enter current password (default: muh#6996)"
              value={currentPasswordConfirm}
              onChange={(e) => setCurrentPasswordConfirm(e.target.value)}
              className="w-full pl-10 pr-3.5 py-2.5 rounded-xl bg-slate-900 border border-amber-500/30 text-xs text-white focus:outline-none focus:border-amber-400 font-mono"
            />
          </div>
          <p className="text-[11px] text-slate-400 mt-1">
            Required to confirm that you are the legitimate owner before saving.
          </p>
        </div>

        <button
          type="submit"
          className="w-full py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs sm:text-sm transition flex items-center justify-center gap-2 cursor-pointer shadow-md shadow-emerald-500/20"
        >
          <ShieldCheck className="w-4 h-4" />
          <span>Save & Apply New Credentials</span>
        </button>
      </form>
    </div>
  );
};
