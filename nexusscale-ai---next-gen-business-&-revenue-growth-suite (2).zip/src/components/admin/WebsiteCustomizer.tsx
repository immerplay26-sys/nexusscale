import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Save, RotateCcw, Check, Sparkles, Sliders, Globe, Phone, Mail, DollarSign, Bell } from 'lucide-react';

export const WebsiteCustomizer: React.FC = () => {
  const { settings, updateSettings, resetSettingsToDefault } = useApp();
  const [form, setForm] = useState({ ...settings });
  const [saved, setSaved] = useState(false);

  const handleChange = (field: string, value: any) => {
    setForm((prev) => ({ ...prev, [field]: value }));
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    updateSettings(form);
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  const handleReset = () => {
    if (window.confirm('Reset all website branding and settings back to original defaults?')) {
      resetSettingsToDefault();
      setForm({ ...settings });
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-white/5">
        <div>
          <h3 className="text-lg font-bold text-white flex items-center gap-2">
            <Sliders className="w-5 h-5 text-emerald-400" />
            <span>Live Website Customization Engine</span>
          </h3>
          <p className="text-xs text-slate-400">
            Edit your brand name, phone, email, pricing plans, and announcement banner. Changes reflect instantly across the entire platform.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleReset}
            className="px-3 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 text-xs font-semibold flex items-center gap-1.5 transition"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Defaults</span>
          </button>
          
          <button
            onClick={handleSave}
            className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-extrabold flex items-center gap-1.5 shadow-md shadow-emerald-500/20 transition cursor-pointer"
          >
            {saved ? <Check className="w-3.5 h-3.5" /> : <Save className="w-3.5 h-3.5" />}
            <span>{saved ? 'Changes Saved!' : 'Save & Publish Live'}</span>
          </button>
        </div>
      </div>

      <form onSubmit={handleSave} className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* Section 1: Branding & Identity */}
        <div className="p-5 rounded-2xl bg-[#090d15] border border-white/5 space-y-4">
          <h4 className="text-xs font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
            <Globe className="w-4 h-4" />
            <span>Brand Identity & Headlines</span>
          </h4>

          <div>
            <label className="text-xs font-semibold text-slate-300 block mb-1">
              Website / Brand Name:
            </label>
            <input
              type="text"
              value={form.siteName}
              onChange={(e) => handleChange('siteName', e.target.value)}
              className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-white/10 text-xs text-white"
            />
          </div>

          <div>
            <label className="text-xs font-semibold text-slate-300 block mb-1">
              Tagline & Value Hook:
            </label>
            <input
              type="text"
              value={form.tagline}
              onChange={(e) => handleChange('tagline', e.target.value)}
              className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-white/10 text-xs text-white"
            />
          </div>

          <div>
            <label className="text-xs font-semibold text-slate-300 block mb-1">
              Hero Main Headline:
            </label>
            <textarea
              rows={2}
              value={form.heroHeadline}
              onChange={(e) => handleChange('heroHeadline', e.target.value)}
              className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-white/10 text-xs text-white resize-none"
            />
          </div>

          <div>
            <label className="text-xs font-semibold text-slate-300 block mb-1">
              Hero Subheadline:
            </label>
            <textarea
              rows={3}
              value={form.heroSubheadline}
              onChange={(e) => handleChange('heroSubheadline', e.target.value)}
              className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-white/10 text-xs text-white resize-none"
            />
          </div>
        </div>

        {/* Section 2: Contact Information */}
        <div className="p-5 rounded-2xl bg-[#090d15] border border-white/5 space-y-4">
          <h4 className="text-xs font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-1.5">
            <Phone className="w-4 h-4" />
            <span>Contact Channels & WhatsApp</span>
          </h4>

          <div>
            <label className="text-xs font-semibold text-slate-300 block mb-1">
              Contact Phone Number:
            </label>
            <input
              type="text"
              value={form.contactPhone}
              onChange={(e) => handleChange('contactPhone', e.target.value)}
              className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-white/10 text-xs text-white"
            />
          </div>

          <div>
            <label className="text-xs font-semibold text-slate-300 block mb-1">
              Official Email Address:
            </label>
            <input
              type="email"
              value={form.contactEmail}
              onChange={(e) => handleChange('contactEmail', e.target.value)}
              className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-white/10 text-xs text-white"
            />
          </div>

          <div>
            <label className="text-xs font-semibold text-slate-300 block mb-1">
              WhatsApp Integration Number:
            </label>
            <input
              type="text"
              value={form.whatsappNumber}
              onChange={(e) => handleChange('whatsappNumber', e.target.value)}
              className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-white/10 text-xs text-white"
            />
          </div>

          {/* Announcement Bar */}
          <div className="pt-2 border-t border-white/5 space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                <Bell className="w-3.5 h-3.5 text-amber-400" />
                <span>Top Banner Announcement</span>
              </label>
              <input
                type="checkbox"
                checked={form.showAnnouncement}
                onChange={(e) => handleChange('showAnnouncement', e.target.checked)}
                className="w-4 h-4 accent-emerald-500 rounded cursor-pointer"
              />
            </div>
            <input
              type="text"
              value={form.announcementText}
              onChange={(e) => handleChange('announcementText', e.target.value)}
              className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-white/10 text-xs text-white"
            />
          </div>
        </div>

        {/* Section 3: Pricing Plans */}
        <div className="p-5 rounded-2xl bg-[#090d15] border border-white/5 space-y-4 md:col-span-2">
          <h4 className="text-xs font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
            <DollarSign className="w-4 h-4" />
            <span>Subscription Pricing Rates (USD / Month)</span>
          </h4>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">
                Starter Solo Plan ($):
              </label>
              <input
                type="number"
                value={form.starterPrice}
                onChange={(e) => handleChange('starterPrice', Number(e.target.value))}
                className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-white/10 text-xs text-white font-mono"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">
                Growth Pro Plan ($):
              </label>
              <input
                type="number"
                value={form.proPrice}
                onChange={(e) => handleChange('proPrice', Number(e.target.value))}
                className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-white/10 text-xs text-white font-mono"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">
                Agency Enterprise Plan ($):
              </label>
              <input
                type="number"
                value={form.agencyPrice}
                onChange={(e) => handleChange('agencyPrice', Number(e.target.value))}
                className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-white/10 text-xs text-white font-mono"
              />
            </div>
          </div>

          <div>
            <label className="text-xs font-semibold text-slate-300 block mb-1">
              SEO Meta Keywords (comma separated):
            </label>
            <input
              type="text"
              value={form.metaKeywords}
              onChange={(e) => handleChange('metaKeywords', e.target.value)}
              className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-white/10 text-xs text-white"
            />
          </div>
        </div>

      </form>
    </div>
  );
};
