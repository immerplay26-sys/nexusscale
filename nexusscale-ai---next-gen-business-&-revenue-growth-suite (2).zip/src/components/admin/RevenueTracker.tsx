import React from 'react';
import { useApp } from '../../context/AppContext';
import { DollarSign, TrendingUp, Users, Award, ShieldCheck, ArrowUpRight } from 'lucide-react';

export const RevenueTracker: React.FC = () => {
  const { leads, settings } = useApp();

  const totalClosedValue = leads
    .filter((l) => l.status === 'closed')
    .reduce((sum, l) => sum + (l.value || 0), 0);

  const potentialPipelineValue = leads
    .filter((l) => l.status !== 'closed')
    .reduce((sum, l) => sum + (l.value || settings.proPrice), 0);

  const totalCustomers = leads.filter((l) => l.status === 'closed').length;
  const simulatedMRR = (totalCustomers * settings.proPrice) + 8420; // Base active subscription pool

  return (
    <div className="space-y-6">
      <div className="pb-4 border-b border-white/5">
        <h3 className="text-lg font-bold text-white flex items-center gap-2">
          <TrendingUp className="w-5 h-5 text-emerald-400" />
          <span>Platform Revenue & Monthly Earnings Monitor</span>
        </h3>
        <p className="text-xs text-slate-400">
          Financial health, client transaction value, and Monthly Recurring Revenue (MRR) metrics.
        </p>
      </div>

      {/* Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 rounded-2xl bg-[#090d15] border border-emerald-500/20">
          <div className="flex items-center justify-between text-slate-400 text-xs mb-2">
            <span>Estimated MRR:</span>
            <span className="text-emerald-400 flex items-center text-[10px] font-bold">
              +18.4% MoM <ArrowUpRight className="w-3 h-3" />
            </span>
          </div>
          <div className="text-2xl sm:text-3xl font-black text-white">
            ${simulatedMRR.toLocaleString()}
          </div>
          <p className="text-[11px] text-emerald-400 mt-1 font-mono">
            ≈ Rs. {(simulatedMRR * 278 / 100000).toFixed(1)} Lakhs PKR / mo
          </p>
        </div>

        <div className="p-5 rounded-2xl bg-[#090d15] border border-cyan-500/20">
          <div className="flex items-center justify-between text-slate-400 text-xs mb-2">
            <span>Pipeline In Negotiation:</span>
            <span className="text-cyan-400 text-[10px] font-bold">{leads.filter(l => l.status === 'new').length} New</span>
          </div>
          <div className="text-2xl sm:text-3xl font-black text-white">
            ${potentialPipelineValue.toLocaleString()}
          </div>
          <p className="text-[11px] text-slate-400 mt-1">
            Active inbound leads
          </p>
        </div>

        <div className="p-5 rounded-2xl bg-[#090d15] border border-purple-500/20">
          <div className="flex items-center justify-between text-slate-400 text-xs mb-2">
            <span>Active Subscribers:</span>
            <span className="text-purple-400 text-[10px] font-bold">Verified</span>
          </div>
          <div className="text-2xl sm:text-3xl font-black text-white">
            {142 + totalCustomers}
          </div>
          <p className="text-[11px] text-slate-400 mt-1">
            Across Solo, Pro & Agency
          </p>
        </div>

        <div className="p-5 rounded-2xl bg-[#090d15] border border-amber-500/20">
          <div className="flex items-center justify-between text-slate-400 text-xs mb-2">
            <span>Lead Conversion Rate:</span>
            <span className="text-amber-400 text-[10px] font-bold">High</span>
          </div>
          <div className="text-2xl sm:text-3xl font-black text-white">
            {leads.length > 0 ? ((totalCustomers / leads.length) * 100).toFixed(1) : 0}%
          </div>
          <p className="text-[11px] text-slate-400 mt-1">
            Inquiry-to-paid client ratio
          </p>
        </div>
      </div>

      {/* Recent Transaction Log */}
      <div className="p-5 rounded-2xl bg-[#090d15] border border-white/5 space-y-3">
        <h4 className="text-xs font-bold text-white uppercase tracking-wider">
          Recent Client Subscriptions & Order Activations
        </h4>
        <div className="space-y-2">
          {leads.map((lead) => (
            <div
              key={lead.id}
              className="p-3 rounded-xl bg-black/40 border border-white/5 flex items-center justify-between text-xs"
            >
              <div>
                <span className="font-bold text-white">{lead.name}</span>
                <span className="text-slate-400 text-[11px] block">{lead.serviceInterest}</span>
              </div>
              <div className="text-right">
                <span className="font-mono font-bold text-emerald-400">
                  +${lead.value || settings.proPrice}
                </span>
                <span className="text-[10px] text-slate-500 block">{lead.date}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
