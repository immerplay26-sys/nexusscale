import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  Users, 
  Download, 
  Trash2, 
  CheckCircle2, 
  Clock, 
  Mail, 
  Phone, 
  MessageSquare,
  Search,
  Filter
} from 'lucide-react';
import { Lead } from '../../types';

export const LeadsManager: React.FC = () => {
  const { leads, updateLeadStatus, deleteLead } = useApp();
  const [filter, setFilter] = useState<'all' | 'new' | 'contacted' | 'closed'>('all');
  const [search, setSearch] = useState('');

  const filteredLeads = leads.filter((lead) => {
    const matchesFilter = filter === 'all' || lead.status === filter;
    const matchesSearch = 
      lead.name.toLowerCase().includes(search.toLowerCase()) ||
      lead.email.toLowerCase().includes(search.toLowerCase()) ||
      lead.serviceInterest.toLowerCase().includes(search.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  const handleExportCSV = () => {
    if (leads.length === 0) return;
    const headers = ['ID', 'Date', 'Name', 'Email', 'Phone', 'Service/Plan', 'Value ($)', 'Status', 'Message'];
    const rows = leads.map((l) => [
      l.id,
      l.date,
      `"${l.name.replace(/"/g, '""')}"`,
      `"${l.email}"`,
      `"${l.phone || ''}"`,
      `"${l.serviceInterest.replace(/"/g, '""')}"`,
      l.value || 0,
      l.status,
      `"${(l.message || '').replace(/"/g, '""')}"`,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `nexusscale_leads_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-white/5">
        <div>
          <h3 className="text-lg font-bold text-white flex items-center gap-2">
            <Users className="w-5 h-5 text-cyan-400" />
            <span>Customer Leads & Inquiries CRM</span>
          </h3>
          <p className="text-xs text-slate-400">
            Real-time inquiries, plan checkout orders, and consultation requests captured across the platform.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCSV}
            className="px-3.5 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-200 text-xs font-semibold flex items-center gap-1.5 transition border border-white/10"
          >
            <Download className="w-3.5 h-3.5 text-emerald-400" />
            <span>Export to CSV</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row gap-3 items-center justify-between">
        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search leads by name, email, or service..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 rounded-xl bg-slate-900 border border-white/10 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
          />
        </div>

        {/* Filter controls (Buttons per frontend design guidelines) */}
        <div className="flex items-center gap-1 p-1 bg-slate-900 rounded-xl border border-white/10 w-full sm:w-auto overflow-x-auto">
          {(['all', 'new', 'contacted', 'closed'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setFilter(tab)}
              className={`px-3 py-1 text-xs font-semibold rounded-lg capitalize transition ${
                filter === tab 
                  ? 'bg-emerald-500 text-slate-950 shadow-sm' 
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {tab} ({tab === 'all' ? leads.length : leads.filter((l) => l.status === tab).length})
            </button>
          ))}
        </div>
      </div>

      {/* Leads Table / Cards */}
      {filteredLeads.length === 0 ? (
        <div className="text-center py-16 p-8 rounded-2xl bg-[#090d15] border border-white/5 space-y-2">
          <Users className="w-10 h-10 text-slate-600 mx-auto" />
          <p className="text-sm font-semibold text-slate-300">No leads match your filter</p>
          <p className="text-xs text-slate-500">New inquiries from contact forms and checkouts will appear here instantly.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredLeads.map((lead) => (
            <div
              key={lead.id}
              className="p-4 sm:p-5 rounded-2xl bg-[#090d15] border border-white/5 hover:border-white/10 transition flex flex-col md:flex-row md:items-center justify-between gap-4"
            >
              <div className="space-y-1.5 flex-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-bold text-white text-sm">{lead.name}</span>
                  <span className="text-xs text-slate-400">·</span>
                  <span className="text-xs text-emerald-400 font-medium">{lead.serviceInterest}</span>
                  {lead.value && lead.value > 0 && (
                    <span className="text-[11px] font-mono font-bold text-cyan-300 bg-cyan-500/10 px-2 py-0.5 rounded border border-cyan-500/20">
                      ${lead.value} Value
                    </span>
                  )}
                  <span className="text-[10px] text-slate-500 ml-auto md:ml-0 font-mono">
                    {lead.date}
                  </span>
                </div>

                <div className="flex flex-wrap items-center gap-3 text-xs text-slate-400">
                  <a href={`mailto:${lead.email}`} className="flex items-center gap-1 hover:text-emerald-400 transition">
                    <Mail className="w-3.5 h-3.5 text-slate-500" />
                    <span>{lead.email}</span>
                  </a>
                  {lead.phone && (
                    <a href={`tel:${lead.phone}`} className="flex items-center gap-1 hover:text-emerald-400 transition">
                      <Phone className="w-3.5 h-3.5 text-slate-500" />
                      <span>{lead.phone}</span>
                    </a>
                  )}
                  <span className="text-slate-600">|</span>
                  <span className="capitalize text-slate-400">Source: {lead.source}</span>
                </div>

                {lead.message && (
                  <p className="text-xs text-slate-300 bg-black/30 p-2.5 rounded-lg border border-white/5 mt-2">
                    "{lead.message}"
                  </p>
                )}
              </div>

              {/* Status & Actions */}
              <div className="flex items-center gap-2 shrink-0 border-t md:border-t-0 pt-3 md:pt-0 border-white/5">
                <select
                  value={lead.status}
                  onChange={(e: any) => updateLeadStatus(lead.id, e.target.value)}
                  className={`text-xs font-semibold px-2.5 py-1.5 rounded-xl border cursor-pointer ${
                    lead.status === 'new'
                      ? 'bg-amber-500/10 text-amber-300 border-amber-500/30'
                      : lead.status === 'contacted'
                        ? 'bg-cyan-500/10 text-cyan-300 border-cyan-500/30'
                        : 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30'
                  }`}
                >
                  <option value="new" className="bg-slate-900 text-white">Status: New</option>
                  <option value="contacted" className="bg-slate-900 text-white">Status: Contacted</option>
                  <option value="closed" className="bg-slate-900 text-white">Status: Closed / Won</option>
                </select>

                <button
                  onClick={() => {
                    if (window.confirm(`Delete lead for ${lead.name}?`)) {
                      deleteLead(lead.id);
                    }
                  }}
                  className="p-2 text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 rounded-lg transition"
                  title="Delete Lead"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
