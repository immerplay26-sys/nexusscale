import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  Mail, 
  Phone, 
  MessageCircle, 
  Send, 
  CheckCircle2, 
  Sparkles, 
  MapPin, 
  Clock, 
  ShieldCheck 
} from 'lucide-react';

export const ContactSection: React.FC = () => {
  const { settings, addLead } = useApp();

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [service, setService] = useState('Growth Pro / Custom Setup');
  const [message, setMessage] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !email.trim() || !message.trim()) return;

    setLoading(true);

    addLead({
      name,
      email,
      phone: phone || 'N/A',
      serviceInterest: service,
      message,
      source: 'contact',
      value: 0,
    });

    setTimeout(() => {
      setLoading(false);
      setSubmitted(true);
    }, 500);
  };

  return (
    <section className="py-16 md:py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto mb-12 space-y-3">
        <div className="inline-flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-emerald-400 bg-emerald-500/10 px-3 py-1 rounded-full border border-emerald-500/20">
          <MessageCircle className="w-3.5 h-3.5" />
          <span>Direct Founder Access & Support</span>
        </div>
        <h2 className="text-2xl sm:text-4xl font-extrabold text-white tracking-tight">
          Get in Touch with Muhammad & the NexusScale Team
        </h2>
        <p className="text-sm sm:text-base text-slate-400">
          Have questions about scaling your agency, custom white-label deployments, or payment inquiries? We respond within 30 minutes.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Left: Contact Info (5 Cols) */}
        <div className="lg:col-span-5 p-6 sm:p-8 rounded-2xl bg-[#0d1320] border border-white/5 space-y-6">
          <h3 className="text-lg font-bold text-white">Direct Communication Channels</h3>
          
          <div className="space-y-4">
            {/* Phone */}
            <div className="flex items-start gap-3.5 p-3.5 rounded-xl bg-white/[0.02] border border-white/5">
              <div className="w-10 h-10 rounded-lg bg-emerald-500/10 text-emerald-400 flex items-center justify-center shrink-0">
                <Phone className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs text-slate-400 font-medium">Direct Telephone & WhatsApp</p>
                <a 
                  href={`tel:${settings.contactPhone}`}
                  className="text-sm font-bold text-white hover:text-emerald-400 transition"
                >
                  {settings.contactPhone}
                </a>
                <p className="text-[11px] text-emerald-400 mt-0.5">Available 24/7 for VIP clients</p>
              </div>
            </div>

            {/* Email */}
            <div className="flex items-start gap-3.5 p-3.5 rounded-xl bg-white/[0.02] border border-white/5">
              <div className="w-10 h-10 rounded-lg bg-cyan-500/10 text-cyan-400 flex items-center justify-center shrink-0">
                <Mail className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs text-slate-400 font-medium">Official Inquiries & Support</p>
                <a 
                  href={`mailto:${settings.contactEmail}`}
                  className="text-sm font-bold text-white hover:text-cyan-400 transition break-all"
                >
                  {settings.contactEmail}
                </a>
                <p className="text-[11px] text-slate-400 mt-0.5">Direct inbox monitored by Muhammad</p>
              </div>
            </div>

            {/* WhatsApp Direct Action */}
            <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/20 space-y-2">
              <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm">
                <MessageCircle className="w-4 h-4" />
                <span>Instant WhatsApp Live Chat</span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                Skip forms and talk directly on WhatsApp with Muhammad for faster response.
              </p>
              <a
                href={`https://wa.me/${settings.whatsappNumber.replace(/[^0-9]/g, '')}?text=Assalam-o-Alaikum%20Muhammad,%20I%20am%20interested%20in%20NexusScale%20AI!`}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-2.5 px-4 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 transition"
              >
                <span>Open WhatsApp Chat Now</span>
                <Send className="w-3.5 h-3.5" />
              </a>
            </div>

            {/* Global Availability */}
            <div className="pt-2 text-xs text-slate-400 space-y-1">
              <div className="flex items-center gap-2">
                <Clock className="w-3.5 h-3.5 text-slate-400" />
                <span>Average Response Time: <strong>&lt; 30 Minutes</strong></span>
              </div>
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>100% Confidential Consultation Guaranteed</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right: Contact Form (7 Cols) */}
        <div className="lg:col-span-7 p-6 sm:p-8 rounded-2xl bg-[#0d1320] border border-white/5 shadow-xl">
          {submitted ? (
            <div className="text-center py-12 space-y-4">
              <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 mx-auto flex items-center justify-center">
                <CheckCircle2 className="w-10 h-10" />
              </div>
              <h3 className="text-2xl font-bold text-white">Message Sent Successfully!</h3>
              <p className="text-sm text-slate-300 max-w-md mx-auto leading-relaxed">
                Thank you for reaching out, <strong>{name}</strong>. Your message has been logged in Muhammad's priority queue. We will get back to you at <strong>{email}</strong> shortly.
              </p>
              <button
                onClick={() => {
                  setSubmitted(false);
                  setName('');
                  setEmail('');
                  setMessage('');
                }}
                className="px-6 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs transition"
              >
                Send Another Message
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <h3 className="text-lg font-bold text-white mb-2">Send an Inquiry or Book VIP Demo</h3>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    Your Name:
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Daniyal Sheikh"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-white/10 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    Email Address:
                  </label>
                  <input
                    type="email"
                    required
                    placeholder="daniyal@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-white/10 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    Phone / WhatsApp (Optional):
                  </label>
                  <input
                    type="tel"
                    placeholder="+92 319 9389323"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-white/10 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    Topic of Interest:
                  </label>
                  <select
                    value={service}
                    onChange={(e) => setService(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-white/10 text-sm text-white focus:outline-none focus:border-emerald-500 transition cursor-pointer"
                  >
                    <option value="Growth Pro Subscription">Growth Pro Subscription ($79/mo)</option>
                    <option value="Agency Enterprise Setup">Agency Enterprise Setup ($199/mo)</option>
                    <option value="White-Label Software Licensing">White-Label Software Licensing</option>
                    <option value="Affiliate Partnership Program">Affiliate Partnership (40%)</option>
                    <option value="Local Payment Method (JazzCash/EasyPaisa/Wire)">Local Payment Methods</option>
                    <option value="General Question for Muhammad">General Question for Muhammad</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">
                  How can we help your business scale?
                </label>
                <textarea
                  required
                  rows={4}
                  placeholder="Tell us about your project, current revenue bottlenecks, or any custom requirements..."
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-white/10 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition resize-none"
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-3.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-sm shadow-lg shadow-emerald-500/20 transition flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>{loading ? 'Submitting Message...' : 'Send Message to Muhammad'}</span>
                <Send className="w-4 h-4" />
              </button>
            </form>
          )}
        </div>

      </div>
    </section>
  );
};
