import React from 'react';
import { useApp } from '../context/AppContext';
import { Award, Target, Rocket, ShieldCheck, Mail, Phone, MessageCircle, ArrowRight } from 'lucide-react';

export const AboutSection: React.FC = () => {
  const { settings, setActiveTab } = useApp();

  return (
    <section className="py-16 md:py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      {/* Title */}
      <div className="text-center max-w-3xl mx-auto mb-16 space-y-3">
        <div className="inline-flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-emerald-400 bg-emerald-500/10 px-3 py-1 rounded-full border border-emerald-500/20">
          <Award className="w-3.5 h-3.5" />
          <span>About NexusScale AI & Leadership</span>
        </div>
        <h2 className="text-2xl sm:text-4xl font-extrabold text-white tracking-tight">
          Engineered to Give Independent Operators an Unfair Advantage
        </h2>
        <p className="text-sm sm:text-base text-slate-400">
          We set out to dismantle the bloated subscription traps of multi-billion dollar SaaS firms and deliver a pure, high-converting revenue powerhouse.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center mb-16">
        {/* Left Column (7 cols) */}
        <div className="lg:col-span-7 space-y-5 text-sm sm:text-base text-slate-300 leading-relaxed">
          <h3 className="text-xl sm:text-2xl font-bold text-white">
            The Vision Behind the Platform
          </h3>
          <p>
            In today's digital landscape, the difference between an agency struggling to survive and one earning <span className="text-emerald-400 font-semibold">lakhs of dollars monthly</span> is not raw talent—it is <strong>speed of execution and algorithmic leverage</strong>.
          </p>
          <p>
            Most freelancers and modern agencies were forced to juggle 6 to 8 disparate subscriptions: one tool for script hooks, another for cold email pitches, another for SEO intelligence, and another for proposal invoices. Costs easily exceeded $700 every single month.
          </p>
          <p>
            {settings.siteName} brings together the 5 highest-leverage growth tools in one unified, blazing-fast workspace. Whether you are generating viral TikTok reels that amass millions of views, crafting high-ticket outreach emails that close $5k B2B deals, or launching scalable micro-SaaS ventures, you can execute in seconds.
          </p>

          <div className="pt-4 flex flex-wrap items-center gap-4">
            <button
              onClick={() => setActiveTab('viral-tool')}
              className="px-6 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-extrabold text-xs sm:text-sm transition flex items-center gap-2 shadow-lg shadow-emerald-500/20"
            >
              <span>Explore The Tools Live</span>
              <ArrowRight className="w-4 h-4" />
            </button>
            <button
              onClick={() => setActiveTab('contact')}
              className="px-5 py-3 rounded-xl bg-white/5 hover:bg-white/10 text-white font-semibold text-xs sm:text-sm transition border border-white/10"
            >
              Connect with Muhammad
            </button>
          </div>
        </div>

        {/* Right Column: Founder Card (5 cols) */}
        <div className="lg:col-span-5 p-6 sm:p-8 rounded-2xl bg-gradient-to-b from-[#0e1726] to-[#09111c] border border-emerald-500/20 shadow-2xl relative">
          <div className="flex items-center gap-4 mb-5">
            <div className="w-16 h-16 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 font-black text-2xl shadow-inner">
              M
            </div>
            <div>
              <h4 className="text-lg font-bold text-white">Muhammad</h4>
              <p className="text-xs text-emerald-400 font-medium">Founder & Chief Architect</p>
              <p className="text-[11px] text-slate-400">Digital Revenue Systems Specialist</p>
            </div>
          </div>

          <div className="space-y-3 text-xs text-slate-300 border-t border-white/5 pt-4">
            <div className="flex items-center gap-2.5">
              <Phone className="w-4 h-4 text-emerald-400 shrink-0" />
              <span><strong>Phone / WhatsApp:</strong> {settings.contactPhone}</span>
            </div>
            <div className="flex items-center gap-2.5">
              <Mail className="w-4 h-4 text-cyan-400 shrink-0" />
              <span><strong>Email:</strong> {settings.contactEmail}</span>
            </div>
            <div className="flex items-center gap-2.5">
              <ShieldCheck className="w-4 h-4 text-teal-400 shrink-0" />
              <span><strong>Headquarters:</strong> Global Distributed Network</span>
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-white/5">
            <a
              href={`https://wa.me/${settings.whatsappNumber.replace(/[^0-9]/g, '')}?text=Hello%20Muhammad,%20I%20read%20your%20about%20page%20and%20want%20to%20collaborate!`}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-2.5 rounded-xl bg-emerald-500/10 text-emerald-300 border border-emerald-500/20 hover:bg-emerald-500/20 font-bold text-xs flex items-center justify-center gap-2 transition"
            >
              <MessageCircle className="w-4 h-4 text-emerald-400" />
              <span>Direct WhatsApp Message</span>
            </a>
          </div>
        </div>
      </div>

      {/* 3 Core Pillars Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="p-6 rounded-2xl bg-[#0c121e] border border-white/5">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center mb-3">
            <Target className="w-5 h-5" />
          </div>
          <h4 className="text-base font-bold text-white mb-1.5">Direct Problem Solving</h4>
          <p className="text-xs text-slate-400 leading-relaxed">
            We don't build generic AI chatbots. Every module solves a specific, burning high-ticket commercial bottleneck.
          </p>
        </div>

        <div className="p-6 rounded-2xl bg-[#0c121e] border border-white/5">
          <div className="w-10 h-10 rounded-xl bg-cyan-500/10 text-cyan-400 flex items-center justify-center mb-3">
            <Rocket className="w-5 h-5" />
          </div>
          <h4 className="text-base font-bold text-white mb-1.5">Lightweight & Blazing Fast</h4>
          <p className="text-xs text-slate-400 leading-relaxed">
            Zero heavy clunky code. Loads instantaneously on any mobile device, 3G/4G network, or desktop without freezing.
          </p>
        </div>

        <div className="p-6 rounded-2xl bg-[#0c121e] border border-white/5">
          <div className="w-10 h-10 rounded-xl bg-purple-500/10 text-purple-400 flex items-center justify-center mb-3">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <h4 className="text-base font-bold text-white mb-1.5">Full Commercial Rights</h4>
          <p className="text-xs text-slate-400 leading-relaxed">
            Everything generated is 100% yours to monetize, license, resell, and deploy without limitations or attribution demands.
          </p>
        </div>
      </div>
    </section>
  );
};
