import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  X, 
  CheckCircle2, 
  ShieldCheck, 
  MessageCircle, 
  CreditCard, 
  Building2, 
  Lock, 
  Sparkles,
  ArrowRight
} from 'lucide-react';

export const CheckoutModal: React.FC = () => {
  const { 
    checkoutModalOpen, 
    setCheckoutModalOpen, 
    selectedPlan, 
    settings, 
    addLead 
  } = useApp();

  const [paymentMethod, setPaymentMethod] = useState<'card' | 'whatsapp' | 'bank'>('whatsapp');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [isSuccess, setIsSuccess] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!checkoutModalOpen) return null;

  const planPrice = 
    selectedPlan === 'Starter' 
      ? settings.starterPrice 
      : selectedPlan === 'Pro' 
        ? settings.proPrice 
        : settings.agencyPrice;

  const handleCompleteOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !email.trim()) return;

    setIsSubmitting(true);

    // Save lead to Admin Database in AppContext
    addLead({
      name,
      email,
      phone: phone || 'Not provided',
      serviceInterest: `${selectedPlan} Subscription ($${planPrice}/mo)`,
      message: `Selected Payment Channel: ${paymentMethod.toUpperCase()}. Order submitted for ${selectedPlan} tier.`,
      plan: selectedPlan,
      source: 'checkout',
      value: planPrice,
    });

    if (paymentMethod === 'whatsapp') {
      const message = `Hello Muhammad! I want to subscribe to ${selectedPlan} Plan on NexusScale AI.\nName: ${name}\nEmail: ${email}\nPhone: ${phone || 'N/A'}\nPlan Value: $${planPrice}/mo`;
      const waUrl = `https://wa.me/${settings.whatsappNumber.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(message)}`;
      window.open(waUrl, '_blank');
    }

    setTimeout(() => {
      setIsSubmitting(false);
      setIsSuccess(true);
    }, 600);
  };

  const handleClose = () => {
    setCheckoutModalOpen(false);
    setIsSuccess(false);
    setName('');
    setEmail('');
    setPhone('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg rounded-2xl bg-[#0d1320] border border-white/10 shadow-2xl p-6 sm:p-8 overflow-hidden">
        
        {/* Close Button */}
        <button
          onClick={handleClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white rounded-lg hover:bg-white/5 transition"
        >
          <X className="w-5 h-5" />
        </button>

        {isSuccess ? (
          <div className="text-center py-8 space-y-4">
            <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 mx-auto flex items-center justify-center">
              <CheckCircle2 className="w-10 h-10" />
            </div>
            <h3 className="text-xl font-bold text-white">Order Registered Successfully!</h3>
            <p className="text-sm text-slate-300 leading-relaxed max-w-sm mx-auto">
              Thank you, <strong>{name}</strong>! Your {selectedPlan} license request has been routed to our verification desk. Founder Muhammad has been notified on WhatsApp (+923199389323).
            </p>
            <div className="p-4 rounded-xl bg-black/40 border border-white/5 text-xs text-slate-400 text-left space-y-1">
              <p>• <strong>Plan:</strong> {selectedPlan} Tier (${planPrice}/mo)</p>
              <p>• <strong>Email:</strong> {email}</p>
              <p>• <strong>Direct Support:</strong> {settings.contactPhone}</p>
            </div>
            <button
              onClick={handleClose}
              className="w-full py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-sm transition"
            >
              Continue to Workspace
            </button>
          </div>
        ) : (
          <div>
            {/* Header */}
            <div className="mb-6">
              <div className="inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-400 bg-emerald-500/10 px-2.5 py-0.5 rounded-full mb-2">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Instant License Activation</span>
              </div>
              <h3 className="text-xl font-extrabold text-white">
                Unlock {selectedPlan} Plan Access
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                Complete your details below. You will receive immediate credentials and invoice receipt.
              </p>
            </div>

            {/* Plan Price Summary */}
            <div className="p-3.5 rounded-xl bg-black/40 border border-white/5 flex items-center justify-between mb-5">
              <div>
                <span className="text-sm font-bold text-white">{selectedPlan} Tier</span>
                <p className="text-[11px] text-slate-400">All features & unlimited generator</p>
              </div>
              <div className="text-right">
                <span className="text-xl font-black text-emerald-400">${planPrice}</span>
                <span className="text-xs text-slate-400"> /mo</span>
              </div>
            </div>

            {/* Payment Method Selector */}
            <div className="mb-5">
              <label className="text-xs font-semibold text-slate-300 block mb-2">
                Select Preferred Payment Route:
              </label>
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setPaymentMethod('whatsapp')}
                  className={`p-2.5 rounded-xl border text-center transition flex flex-col items-center gap-1.5 ${
                    paymentMethod === 'whatsapp'
                      ? 'border-emerald-500 bg-emerald-500/10 text-emerald-300'
                      : 'border-white/5 bg-white/[0.02] text-slate-400 hover:border-white/20'
                  }`}
                >
                  <MessageCircle className="w-4 h-4 text-emerald-400" />
                  <span className="text-[11px] font-bold">WhatsApp Direct</span>
                </button>

                <button
                  type="button"
                  onClick={() => setPaymentMethod('card')}
                  className={`p-2.5 rounded-xl border text-center transition flex flex-col items-center gap-1.5 ${
                    paymentMethod === 'card'
                      ? 'border-emerald-500 bg-emerald-500/10 text-emerald-300'
                      : 'border-white/5 bg-white/[0.02] text-slate-400 hover:border-white/20'
                  }`}
                >
                  <CreditCard className="w-4 h-4 text-cyan-400" />
                  <span className="text-[11px] font-bold">Card / Stripe</span>
                </button>

                <button
                  type="button"
                  onClick={() => setPaymentMethod('bank')}
                  className={`p-2.5 rounded-xl border text-center transition flex flex-col items-center gap-1.5 ${
                    paymentMethod === 'bank'
                      ? 'border-emerald-500 bg-emerald-500/10 text-emerald-300'
                      : 'border-white/5 bg-white/[0.02] text-slate-400 hover:border-white/20'
                  }`}
                >
                  <Building2 className="w-4 h-4 text-purple-400" />
                  <span className="text-[11px] font-bold">Bank / JazzCash</span>
                </button>
              </div>
            </div>

            {/* Form */}
            <form onSubmit={handleCompleteOrder} className="space-y-3.5">
              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">
                  Full Name:
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Alex Henderson or Hamza Tariq"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-white/10 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">
                  Email Address (For License & Login):
                </label>
                <input
                  type="email"
                  required
                  placeholder="e.g. name@company.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-white/10 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">
                  WhatsApp / Phone Number (Optional):
                </label>
                <input
                  type="tel"
                  placeholder="+92 3XX XXXXXXX or international"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-white/10 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition"
                />
              </div>

              {paymentMethod === 'card' && (
                <div className="p-3 rounded-xl bg-slate-900/80 border border-white/10 space-y-2">
                  <div className="flex items-center gap-1.5 text-xs text-slate-300 font-semibold">
                    <Lock className="w-3.5 h-3.5 text-emerald-400" />
                    <span>256-Bit SSL Secure Checkout Demo</span>
                  </div>
                  <input
                    type="text"
                    placeholder="4242 •••• •••• 4242"
                    defaultValue="4242 8820 9102 3341"
                    className="w-full px-3 py-2 rounded-lg bg-black/50 border border-white/10 text-xs text-slate-300 font-mono"
                  />
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="text"
                      placeholder="MM/YY"
                      defaultValue="12/28"
                      className="px-3 py-1.5 rounded-lg bg-black/50 border border-white/10 text-xs text-slate-300 font-mono"
                    />
                    <input
                      type="text"
                      placeholder="CVC"
                      defaultValue="786"
                      className="px-3 py-1.5 rounded-lg bg-black/50 border border-white/10 text-xs text-slate-300 font-mono"
                    />
                  </div>
                </div>
              )}

              {paymentMethod === 'bank' && (
                <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-xs text-slate-300 space-y-1">
                  <p className="font-bold text-emerald-300">Direct Local & Wire Transfer Details:</p>
                  <p>• <strong>EasyPaisa / JazzCash / Mobile:</strong> +923199389323</p>
                  <p>• <strong>Account Title:</strong> Muhammad</p>
                  <p>• <strong>Crypto USDT (TRC-20):</strong> Available on request via WhatsApp</p>
                  <p className="text-[11px] text-slate-400">After sending, your receipt is verified within 10 minutes.</p>
                </div>
              )}

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full mt-2 py-3.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-sm shadow-lg shadow-emerald-500/20 transition flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>{paymentMethod === 'whatsapp' ? 'Continue with WhatsApp (+923199389323)' : `Confirm & Pay $${planPrice}`}</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <div className="flex items-center justify-center gap-2 text-[11px] text-slate-400 pt-1">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>Encrypted · Instant Confirmation · Cancel Anytime</span>
              </div>
            </form>
          </div>
        )}

      </div>
    </div>
  );
};
