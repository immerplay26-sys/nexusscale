import React from 'react';
import { useApp } from '../context/AppContext';
import { X, ShieldCheck, FileText, RefreshCw, Award, Mail, Phone, MessageCircle } from 'lucide-react';

export const LegalModals: React.FC = () => {
  const { activeLegalModal, setActiveLegalModal, settings } = useApp();

  if (!activeLegalModal) return null;

  const handleClose = () => setActiveLegalModal(null);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl max-h-[85vh] rounded-2xl bg-[#0d1320] border border-white/10 shadow-2xl p-6 sm:p-8 overflow-y-auto">
        
        {/* Close Button */}
        <button
          onClick={handleClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white rounded-lg hover:bg-white/5 transition"
        >
          <X className="w-5 h-5" />
        </button>

        {/* 1. Privacy Policy */}
        {activeLegalModal === 'privacy' && (
          <div className="space-y-4 text-slate-300 text-xs sm:text-sm leading-relaxed">
            <div className="flex items-center gap-2 text-emerald-400 font-bold text-lg mb-2">
              <ShieldCheck className="w-6 h-6" />
              <span>Privacy Policy & Data Security</span>
            </div>
            <p className="text-slate-400">Effective Date: January 1, 2026 · Last Updated: September 2026</p>
            
            <h4 className="text-white font-bold text-sm sm:text-base">1. Commitment to Data Sovereignty</h4>
            <p>
              At {settings.siteName}, your intellectual property, client leads, and generated prompts are strictly confidential. We do not sell, rent, or trade your private data to third-party ad networks or brokers.
            </p>

            <h4 className="text-white font-bold text-sm sm:text-base">2. Information Collection</h4>
            <p>
              We collect minimal information necessary to deliver and customize our services, such as your contact name, email address, transaction records, and workspace preferences.
            </p>

            <h4 className="text-white font-bold text-sm sm:text-base">3. AI Safety & Zero Data Retention for Training</h4>
            <p>
              All generations executed through our AI pipelines are processed securely. Your proprietary business outreach pitches, SEO strategies, and video hooks are not used to train public foundational AI models.
            </p>

            <h4 className="text-white font-bold text-sm sm:text-base">4. Contact & Inquiries</h4>
            <p>
              If you have any questions regarding our compliance or data protection policies, please contact our Data Governance Officer, Muhammad, at {settings.contactEmail} or by phone at {settings.contactPhone}.
            </p>
          </div>
        )}

        {/* 2. Terms of Service */}
        {activeLegalModal === 'terms' && (
          <div className="space-y-4 text-slate-300 text-xs sm:text-sm leading-relaxed">
            <div className="flex items-center gap-2 text-cyan-400 font-bold text-lg mb-2">
              <FileText className="w-6 h-6" />
              <span>Terms of Service & Licensing</span>
            </div>
            <p className="text-slate-400">Effective Date: January 1, 2026</p>
            
            <h4 className="text-white font-bold text-sm sm:text-base">1. Agreement to Terms</h4>
            <p>
              By accessing or using {settings.siteName}, you agree to be bound by these Terms of Service. If you do not agree with any part of these terms, you may not access our software.
            </p>

            <h4 className="text-white font-bold text-sm sm:text-base">2. Commercial Use & Ownership of Outputs</h4>
            <p>
              You maintain 100% full commercial ownership of all viral scripts, cold emails, SEO architectures, and proposals generated using {settings.siteName}. You are permitted to resell, publish, or distribute them to clients worldwide with zero royalty obligations.
            </p>

            <h4 className="text-white font-bold text-sm sm:text-base">3. Acceptable Use Policy</h4>
            <p>
              You agree not to use the suite to distribute spam, malware, harassing material, or conduct unlawful fraud. Misuse will result in immediate termination of the license without refund.
            </p>

            <h4 className="text-white font-bold text-sm sm:text-base">4. Subscription Billing & Cancellation</h4>
            <p>
              Subscriptions renew automatically on a monthly or annual basis depending on your plan. You may cancel your subscription at any time via your user dashboard or by messaging support at {settings.contactEmail}.
            </p>
          </div>
        )}

        {/* 3. Refund Policy */}
        {activeLegalModal === 'refund' && (
          <div className="space-y-4 text-slate-300 text-xs sm:text-sm leading-relaxed">
            <div className="flex items-center gap-2 text-emerald-400 font-bold text-lg mb-2">
              <RefreshCw className="w-6 h-6" />
              <span>30-Day Money-Back Guarantee & Refund Policy</span>
            </div>
            
            <p>
              We stand 100% behind the quality and high-income generation capabilities of {settings.siteName}.
            </p>

            <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 text-xs sm:text-sm">
              <strong>Our Iron-Clad 30-Day Promise:</strong> If you use our AI Viral Studio, High-Ticket Outreach Closer, or SEO suite for 30 days and feel it has not saved you dozens of hours or paid for itself, simply message us for a prompt, unconditional 100% refund.
            </div>

            <h4 className="text-white font-bold text-sm sm:text-base">How to Claim a Refund:</h4>
            <p>
              Simply email <strong>{settings.contactEmail}</strong> or send a WhatsApp message to <strong>{settings.contactPhone}</strong> with your order email and payment receipt. Your refund will be processed back to your original payment method within 2–5 business days.
            </p>
          </div>
        )}

        {/* 4. Founder Story */}
        {activeLegalModal === 'founder' && (
          <div className="space-y-4 text-slate-300 text-xs sm:text-sm leading-relaxed">
            <div className="flex items-center gap-2 text-emerald-400 font-bold text-lg mb-2">
              <Award className="w-6 h-6" />
              <span>Founder Story & Mission</span>
            </div>
            
            <p>
              {settings.siteName} was founded and engineered by <strong>Muhammad</strong> with a single mission: to level the playing field for ambitious creators, digital freelancers, and modern agencies across the globe.
            </p>

            <p>
              "For years, Silicon Valley software companies charged $80 to $250 every single month for basic tools—one subscription for scripts, another for emails, another for SEO, and another for proposals. Most talented operators were spending half their profits just on software bills."
            </p>

            <p>
              "We engineered {settings.siteName} to be faster, cleaner, more practical, and significantly more lucrative. We built an engine that directly helps you close deals, scale viral presence, and earn substantial monthly revenue (lakhoon dollar kama saku) with zero fluff."
            </p>

            <div className="p-4 rounded-xl bg-black/40 border border-white/5 space-y-2 text-xs">
              <p className="font-bold text-white">Direct Founder Contact:</p>
              <p className="flex items-center gap-2">
                <Phone className="w-3.5 h-3.5 text-emerald-400" />
                <span><strong>Phone / WhatsApp:</strong> {settings.contactPhone}</span>
              </p>
              <p className="flex items-center gap-2">
                <Mail className="w-3.5 h-3.5 text-cyan-400" />
                <span><strong>Email:</strong> {settings.contactEmail}</span>
              </p>
            </div>
          </div>
        )}

        <div className="pt-6 border-t border-white/5 flex justify-end">
          <button
            onClick={handleClose}
            className="px-5 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white font-semibold text-xs transition"
          >
            Close Window
          </button>
        </div>

      </div>
    </div>
  );
};
