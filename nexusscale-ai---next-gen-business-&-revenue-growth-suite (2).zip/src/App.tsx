import React, { useEffect } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { Hero } from './components/Hero';
import { LiveDemoShowcase } from './components/LiveDemoShowcase';
import { ROICalculator } from './components/ROICalculator';
import { PricingSection } from './components/PricingSection';
import { AboutSection } from './components/AboutSection';
import { ContactSection } from './components/ContactSection';
import { CheckoutModal } from './components/CheckoutModal';
import { AffiliateModal } from './components/AffiliateModal';
import { LegalModals } from './components/LegalModals';

// Tools
import { ViralScriptTool } from './components/tools/ViralScriptTool';
import { HighTicketOutreachTool } from './components/tools/HighTicketOutreachTool';
import { ProgrammaticSEOTool } from './components/tools/ProgrammaticSEOTool';
import { SaaSIdeaValidatorTool } from './components/tools/SaaSIdeaValidatorTool';
import { ProposalInvoiceTool } from './components/tools/ProposalInvoiceTool';

// Admin
import { AdminLogin } from './components/admin/AdminLogin';
import { AdminDashboard } from './components/admin/AdminDashboard';

const MainContent: React.FC = () => {
  const { activeTab, isAdminLoggedIn, settings } = useApp();

  // Dynamic document title update according to customized site settings
  useEffect(() => {
    document.title = `${settings.siteName} - ${settings.tagline}`;
  }, [settings.siteName, settings.tagline]);

  const renderActiveView = () => {
    switch (activeTab) {
      case 'viral-tool':
        return <ViralScriptTool />;
      case 'outreach-tool':
        return <HighTicketOutreachTool />;
      case 'seo-tool':
        return <ProgrammaticSEOTool />;
      case 'validator-tool':
        return <SaaSIdeaValidatorTool />;
      case 'proposal-tool':
        return <ProposalInvoiceTool />;
      case 'pricing':
        return <PricingSection />;
      case 'roi':
        return <ROICalculator />;
      case 'about':
        return <AboutSection />;
      case 'contact':
        return <ContactSection />;
      case 'admin-login':
        return isAdminLoggedIn ? <AdminDashboard /> : <AdminLogin />;
      case 'admin-dashboard':
        return isAdminLoggedIn ? <AdminDashboard /> : <AdminLogin />;
      case 'home':
      default:
        return (
          <>
            <Hero />
            <LiveDemoShowcase />
            <ROICalculator />
            <PricingSection />
            <AboutSection />
            <ContactSection />
          </>
        );
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#080b11] text-slate-100 font-sans selection:bg-emerald-500/30 selection:text-emerald-200">
      <Navbar />
      <main className="flex-1 w-full">
        {renderActiveView()}
      </main>
      <Footer />

      {/* Global Modals */}
      <CheckoutModal />
      <AffiliateModal />
      <LegalModals />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainContent />
    </AppProvider>
  );
}
