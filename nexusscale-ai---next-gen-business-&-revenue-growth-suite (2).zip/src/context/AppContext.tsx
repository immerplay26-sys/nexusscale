import React, { createContext, useContext, useState, useEffect } from 'react';
import { SiteSettings, Lead, AdminCredentials, ActiveTab } from '../types';

interface AppContextType {
  settings: SiteSettings;
  updateSettings: (newSettings: Partial<SiteSettings>) => void;
  resetSettingsToDefault: () => void;
  adminCreds: AdminCredentials;
  updateAdminCredentials: (creds: AdminCredentials) => void;
  isAdminLoggedIn: boolean;
  adminLogin: (email: string, pass: string) => boolean;
  adminLogout: () => void;
  leads: Lead[];
  addLead: (lead: Omit<Lead, 'id' | 'date' | 'status'>) => void;
  updateLeadStatus: (id: string, status: Lead['status']) => void;
  deleteLead: (id: string) => void;
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  checkoutModalOpen: boolean;
  setCheckoutModalOpen: (open: boolean) => void;
  selectedPlan: 'Starter' | 'Pro' | 'Agency';
  setSelectedPlan: (plan: 'Starter' | 'Pro' | 'Agency') => void;
  affiliateModalOpen: boolean;
  setAffiliateModalOpen: (open: boolean) => void;
  activeLegalModal: 'privacy' | 'terms' | 'refund' | 'founder' | null;
  setActiveLegalModal: (modal: 'privacy' | 'terms' | 'refund' | 'founder' | null) => void;
}

const DEFAULT_SETTINGS: SiteSettings = {
  siteName: 'NexusScale AI',
  tagline: 'The Ultimate AI Revenue Engine & Business Growth Suite',
  description: 'Empowering entrepreneurs, agencies, and creators with world-class viral content studios, high-ticket deal closers, programmatic SEO, and venture scalability tools.',
  announcementText: '🔥 Flash Launch Offer: Unlimited AI Generation + 40% Affiliate Commission Active!',
  showAnnouncement: true,
  contactPhone: '+923199389323',
  contactEmail: 'muhammadofficial356@gmail.com',
  whatsappNumber: '+923199389323',
  currency: 'USD',
  heroHeadline: 'Launch, Scale & Monetize Your Digital Empire with AI Super-Tools',
  heroSubheadline: 'Replace 7 expensive subscriptions ($600+/month) with one single intelligent platform. Create viral media, close $5k clients, build programmatic SEO, and launch scalable ventures.',
  starterPrice: 29,
  proPrice: 79,
  agencyPrice: 199,
  metaKeywords: 'ai business tools, viral video script generator, high ticket client outreach, programmatic seo software, micro saas validator, pakistani entrepreneur, make money online',
};

const DEFAULT_CREDS: AdminCredentials = {
  email: 'muhammadofficial356@gmail.com',
  password: 'muh#6996',
};

const INITIAL_LEADS: Lead[] = [
  {
    id: 'lead-1',
    name: 'David Sterling',
    email: 'david@sterlingmedia.io',
    phone: '+1 415 890 2211',
    serviceInterest: 'Agency Enterprise Plan ($199/mo)',
    message: 'We run a 14-person video agency and want to integrate NexusScale AI for all our creator client viral hooks.',
    plan: 'Agency',
    source: 'checkout',
    date: '2026-09-27 18:40',
    status: 'new',
    value: 199,
  },
  {
    id: 'lead-2',
    name: 'Sarah Khan',
    email: 'sarah.growth@gmail.com',
    phone: '+92 300 445 1199',
    serviceInterest: 'High-Ticket Outreach Closer & SEO',
    message: 'Assalam-o-Alaikum Muhammad, saw your viral post on B2B lead generation. Interested in customized white-label setup.',
    plan: 'Pro',
    source: 'contact',
    date: '2026-09-28 02:15',
    status: 'contacted',
    value: 79,
  },
  {
    id: 'lead-3',
    name: 'Markus Lindqvist',
    email: 'markus@nordicventures.co',
    phone: '+46 70 123 4567',
    serviceInterest: 'VIP Demo & Multi-Seat License',
    message: 'Looking to roll this out across 5 portfolio e-commerce and micro-SaaS companies.',
    plan: 'Agency',
    source: 'demo',
    date: '2026-09-28 05:22',
    status: 'closed',
    value: 597,
  },
];

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Load settings from localStorage or fallback
  const [settings, setSettings] = useState<SiteSettings>(() => {
    try {
      const saved = localStorage.getItem('nexus_settings');
      return saved ? { ...DEFAULT_SETTINGS, ...JSON.parse(saved) } : DEFAULT_SETTINGS;
    } catch {
      return DEFAULT_SETTINGS;
    }
  });

  // Load Admin Credentials
  const [adminCreds, setAdminCreds] = useState<AdminCredentials>(() => {
    try {
      const saved = localStorage.getItem('nexus_admin_creds');
      return saved ? JSON.parse(saved) : DEFAULT_CREDS;
    } catch {
      return DEFAULT_CREDS;
    }
  });

  // Admin login session
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState<boolean>(() => {
    try {
      return sessionStorage.getItem('nexus_admin_auth') === 'true';
    } catch {
      return false;
    }
  });

  // Leads state
  const [leads, setLeads] = useState<Lead[]>(() => {
    try {
      const saved = localStorage.getItem('nexus_leads');
      return saved ? JSON.parse(saved) : INITIAL_LEADS;
    } catch {
      return INITIAL_LEADS;
    }
  });

  // Navigation tab
  const [activeTab, setActiveTabState] = useState<ActiveTab>(() => {
    // Check URL on load for /admin-login.html or ?route=admin-login
    if (typeof window !== 'undefined') {
      const path = window.location.pathname.toLowerCase();
      const search = window.location.search.toLowerCase();
      if (path.includes('admin-login') || search.includes('admin-login') || search.includes('admin')) {
        return 'admin-login';
      }
    }
    return 'home';
  });

  // Modals
  const [checkoutModalOpen, setCheckoutModalOpen] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState<'Starter' | 'Pro' | 'Agency'>('Pro');
  const [affiliateModalOpen, setAffiliateModalOpen] = useState(false);
  const [activeLegalModal, setActiveLegalModal] = useState<'privacy' | 'terms' | 'refund' | 'founder' | null>(null);

  // Sync settings to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('nexus_settings', JSON.stringify(settings));
    } catch (e) {
      console.error(e);
    }
  }, [settings]);

  // Sync credentials to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('nexus_admin_creds', JSON.stringify(adminCreds));
    } catch (e) {
      console.error(e);
    }
  }, [adminCreds]);

  // Sync leads to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('nexus_leads', JSON.stringify(leads));
    } catch (e) {
      console.error(e);
    }
  }, [leads]);

  // Listen to popstate / url changes
  useEffect(() => {
    const handleUrlCheck = () => {
      const path = window.location.pathname.toLowerCase();
      const search = window.location.search.toLowerCase();
      if (path.includes('admin-login') || search.includes('admin-login')) {
        if (isAdminLoggedIn) {
          setActiveTabState('admin-dashboard');
        } else {
          setActiveTabState('admin-login');
        }
      }
    };
    window.addEventListener('popstate', handleUrlCheck);
    return () => window.removeEventListener('popstate', handleUrlCheck);
  }, [isAdminLoggedIn]);

  const setActiveTab = (tab: ActiveTab) => {
    setActiveTabState(tab);
    // Smooth scroll to top on tab change
    window.scrollTo({ top: 0, behavior: 'smooth' });
    
    // Update browser URL query/path history gracefully without full reload
    if (typeof window !== 'undefined') {
      if (tab === 'admin-login') {
        window.history.pushState({}, '', '/admin-login.html');
      } else if (tab === 'admin-dashboard') {
        window.history.pushState({}, '', '/admin-dashboard');
      } else if (tab === 'home') {
        window.history.pushState({}, '', '/');
      } else {
        window.history.pushState({}, '', `/#${tab}`);
      }
    }
  };

  const updateSettings = (newSettings: Partial<SiteSettings>) => {
    setSettings((prev) => ({ ...prev, ...newSettings }));
  };

  const resetSettingsToDefault = () => {
    setSettings(DEFAULT_SETTINGS);
    try {
      localStorage.removeItem('nexus_settings');
    } catch (e) {
      console.error(e);
    }
  };

  const updateAdminCredentials = (creds: AdminCredentials) => {
    setAdminCreds(creds);
  };

  const adminLogin = (email: string, pass: string): boolean => {
    // Check against configured admin credentials (or fallback default)
    const validEmail = adminCreds.email.trim().toLowerCase();
    const validPass = adminCreds.password;
    if (email.trim().toLowerCase() === validEmail && pass === validPass) {
      setIsAdminLoggedIn(true);
      sessionStorage.setItem('nexus_admin_auth', 'true');
      setActiveTab('admin-dashboard');
      return true;
    }
    return false;
  };

  const adminLogout = () => {
    setIsAdminLoggedIn(false);
    sessionStorage.removeItem('nexus_admin_auth');
    setActiveTab('home');
  };

  const addLead = (lead: Omit<Lead, 'id' | 'date' | 'status'>) => {
    const newLead: Lead = {
      ...lead,
      id: `lead-${Date.now()}`,
      date: new Date().toISOString().replace('T', ' ').substring(0, 16),
      status: 'new',
    };
    setLeads((prev) => [newLead, ...prev]);
  };

  const updateLeadStatus = (id: string, status: Lead['status']) => {
    setLeads((prev) =>
      prev.map((item) => (item.id === id ? { ...item, status } : item))
    );
  };

  const deleteLead = (id: string) => {
    setLeads((prev) => prev.filter((item) => item.id !== id));
  };

  return (
    <AppContext.Provider
      value={{
        settings,
        updateSettings,
        resetSettingsToDefault,
        adminCreds,
        updateAdminCredentials,
        isAdminLoggedIn,
        adminLogin,
        adminLogout,
        leads,
        addLead,
        updateLeadStatus,
        deleteLead,
        activeTab,
        setActiveTab,
        checkoutModalOpen,
        setCheckoutModalOpen,
        selectedPlan,
        setSelectedPlan,
        affiliateModalOpen,
        setAffiliateModalOpen,
        activeLegalModal,
        setActiveLegalModal,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
