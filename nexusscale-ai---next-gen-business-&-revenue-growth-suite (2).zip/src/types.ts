export interface SiteSettings {
  siteName: string;
  tagline: string;
  description: string;
  announcementText: string;
  showAnnouncement: boolean;
  contactPhone: string;
  contactEmail: string;
  whatsappNumber: string;
  currency: string;
  heroHeadline: string;
  heroSubheadline: string;
  starterPrice: number;
  proPrice: number;
  agencyPrice: number;
  metaKeywords: string;
}

export interface Lead {
  id: string;
  name: string;
  email: string;
  phone?: string;
  serviceInterest: string;
  message: string;
  plan?: string;
  source: 'contact' | 'checkout' | 'demo' | 'newsletter' | 'affiliate';
  date: string;
  status: 'new' | 'contacted' | 'closed';
  value?: number;
}

export interface AdminCredentials {
  email: string;
  password: string;
}

export interface GenerationResult {
  title: string;
  content: string;
  timestamp: string;
  metadata?: Record<string, any>;
}

export type ActiveTab = 
  | 'home' 
  | 'viral-tool' 
  | 'outreach-tool' 
  | 'seo-tool' 
  | 'validator-tool' 
  | 'proposal-tool' 
  | 'pricing' 
  | 'roi' 
  | 'about' 
  | 'contact' 
  | 'admin-login' 
  | 'admin-dashboard';
